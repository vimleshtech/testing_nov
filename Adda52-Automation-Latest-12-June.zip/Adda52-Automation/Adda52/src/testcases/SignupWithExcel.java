//=======================================================================================
// --- Created By: Rahul Shrivastava
// --- Created Date: 16-06-2014
// --- Modified Date: 
// --- Modified By: 
//=======================================================================================

package testcases;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilities.Common;
import utilities.ExcelUtility;

public class SignupWithExcel {

	private WebDriver driver;
	private String baseUrl;

	ExcelUtility utility = new ExcelUtility();

	HashMap<String, String> signUpMsgMap = new HashMap<String, String>();

	@Before
	public void setUp() throws Exception {
		driver = new FirefoxDriver();
		baseUrl = "http://adda52.org/";
		driver.get(baseUrl);
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	}

	// SignUp using Excel data

	@Test
	public void SignUpWithExcel() {

		// to set the waiting time for the driver... // it is required here
		// before jumping to any conclusion of signup..

		// Start

		String mapvalue = "";

		WebDriverWait wait = new WebDriverWait(driver, 10);

		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

		// End

		String currentURL = null;

		// ExcelUtiltiy.readUserData() will read the entire excel and put each
		// row of excel in hashmp and then add the hashmap to the List // We
		// will
		// then fetch the list here

		ArrayList<HashMap<String, Object>> userMapList = (ArrayList<HashMap<String, Object>>) utility
				.readUserData();
		utility.readExcelTestCases("User.xls");
		WebElement element = null;
		String elementStyle = "";

		// executor to run javascript commands

		JavascriptExecutor executor = null;

		try {

			// Looping the list and getting each hashmap or row of excel and
			// signing
			// up //to-do----We can put the entire message of System.out.println
			// in
			// excel against each user to get to know which user get signed up
			// susccessful and which user get which message.

			for (HashMap<String, Object> userMap : userMapList) {

				System.out.println("USERMAP ELEMENT  "
						+ userMap.get("userName"));

				driver.get(baseUrl + "/");

				final String previousURL = driver.getCurrentUrl();

				mapvalue = "";

				// In case of successful signup user will get login, the very
				// next time
				// we will hit adda52.com. // To prevent this we need to find
				// logout button
				// and click on that and then hit adda52.com again.

				if (driver.findElements(By.xpath("//*[@id='logout']/img"))
						.size() != 0) {
					driver.findElement(By.xpath("//*[@id='logout']/img"))
							.click();
				}
				driver.get(baseUrl + "/");

				if (driver.findElements(
						By.xpath("html/body/div[3]/div/div/img")).size() != 0) {
					driver.findElement(By.xpath("html/body/div[3]/div/div/img"))
							.click();
				}

				// driver.findElement(By.id("reg_username")).clear();
				driver.findElement(By.id("reg_username")).sendKeys(
						userMap.get("userName").toString());

				// driver.findElement(By.id("password_clear")).clear();
				driver.findElement(By.xpath("//*[@id='password_clear']"))
						.sendKeys(userMap.get("password").toString());

				element = driver.findElement(By.id("password_clear"));
				elementStyle = element.getAttribute("style");
				System.out.println(elementStyle + "TEXT");

				if (driver.findElement(By.id("password_clear")).isDisplayed()
						|| elementStyle.equals("display: inline;")) {
					driver.findElement(By.id("password_clear")).clear();
					driver.findElement(By.xpath("//*[@id='password_clear']"))
							.click();
				}

				// Running javascript to make the password field
				// displayed---Start

				executor = (JavascriptExecutor) driver;
				executor.executeScript("document.getElementById('reg_password').style.display='inline';");

				// ----End----

				if (driver.findElement(By.id("reg_password")).isDisplayed()
						|| elementStyle.equals("display: inline;")) {
					driver.findElement(By.id("reg_password")).clear();
					driver.findElement(By.xpath("//*[@id='reg_password']"))
							.sendKeys(userMap.get("password").toString());
				}

				driver.findElement(By.id("email")).clear();
				driver.findElement(By.id("email")).sendKeys(
						userMap.get("email").toString());

				driver.findElement(By.id("dobyear")).sendKeys(
						userMap.get("birthYear").toString().equals("0.0") ? ""
								: userMap.get("birthYear").toString());

				driver.findElement(By.id("gender")).sendKeys(
						userMap.get("gender").toString());

				driver.findElement(By.xpath("//*[@id='agree']")).click();
				driver.findElement(By.id("btn-signup")).click();

				// setting condition to come out of wait mode..

				ExpectedCondition e = new ExpectedCondition<Boolean>() {

					@Override
					public Boolean apply(WebDriver d) {
						return (d.getCurrentUrl() != previousURL);
					}
				};

				wait.until(e);

				// If after clicking fo signup button and waiting for 30
				// seconds..URL
				// remains the same, // it means sign up is not succussful and
				// we will check
				// the message

				currentURL = driver.getCurrentUrl();
				if (currentURL.equals(previousURL)) {

					if (driver.findElements(By.xpath("//*[@id='reg_pwd']"))
							.size() != 0) {

						if (driver
								.findElement(By.xpath("//*[@id='reg_pwd']"))
								.getText()
								.equals("The Password field must be minimum 8 and maximum 20 characters in length.")) {
							System.out
									.println(userMap.get("userName").toString()
											+ "::"
											+ "The Password field must be minimum 8 and maximum 20 characters in length.");
							// continue;
							mapvalue = mapvalue
									+ " "
									+ "The Password field must be minimum 8 and maximum 20 characters in length.";

						}
						if (driver.findElement(By.xpath("//*[@id='reg_pwd']"))
								.getText()
								.equals("The Password field is required.")) {
							System.out.println(userMap.get("userName")
									.toString()
									+ "::"
									+ "The Password field is required.");
							// continue;
							mapvalue = mapvalue + " "
									+ "The Password field is required.";
						}
					}

					if (driver.findElements(By.xpath("//*[@id='reg_uname']"))
							.size() != 0) {
						if (driver
								.findElement(By.xpath("//*[@id='reg_pwd']"))
								.getText()
								.equals("User Name already exists. Please use a different one.")) {
							System.out
									.println(userMap.get("userName").toString()
											+ "::"
											+ "User Name already exists. Please use a different one.");
							// continue;
							mapvalue = mapvalue
									+ " "
									+ "User Name already exists. Please use a different one.";
						}

						if (driver
								.findElement(By.xpath("//*[@id='reg_uname']"))
								.getText()
								.equals("The User Name field is required.")) {
							System.out.println(userMap.get("userName")
									.toString()
									+ "::"
									+ "The User Name field is required.");
							// continue;
							mapvalue = mapvalue + " "
									+ "The User Name field is required.";
						}

						if (driver
								.findElement(By.xpath("//*[@id='reg_uname']"))
								.getText()
								.equals("The User Name field may only contain alphanumeric characters.")) {
							System.out
									.println(userMap.get("userName").toString()
											+ "::"
											+ "The User Name field may only contain alphanumeric characters.");
							// continue;
							mapvalue = mapvalue
									+ " "
									+ "The User Name field may only contain alphanumeric characters.";
						}

					}

					if (driver.findElements(By.xpath("//*[@id='reg_email']"))
							.size() != 0) {
						if (driver
								.findElement(By.xpath("//*[@id='reg_email']"))
								.getText()
								.equals("The Email field is required.")) {
							System.out.println(userMap.get("userName")
									.toString()
									+ "::"
									+ "The Email field is required.");
							// continue;
							mapvalue = mapvalue + " "
									+ "The Email field is required.";

						}

					}

					if (driver.findElements(By.xpath("//*[@id='reg_dobyear']"))
							.size() != 0) {
						if (driver
								.findElement(By.xpath("//*[@id='reg_dobyear']"))
								.getText()
								.equals("The Birth Year field is required.")) {

							System.out.println(userMap.get("userName")
									.toString()
									+ "::"
									+ "The Birth Year field is required.");
							// continue;
							mapvalue = mapvalue + " "
									+ "The Birth Year field is required.";

						}

					}
				}

				if (driver.findElements(By.xpath("//*[@id='reg_gender']"))
						.size() != 0) {

					if (driver.findElement(By.xpath("//*[@id='reg_gender']"))
							.getText().equals("The Gender field is required.")) {

						System.out.println(userMap.get("userName").toString()
								+ "::" + "The Gender field is required.");
						// continue;
						mapvalue = mapvalue + " "
								+ "The Gender field is required.";

					}

				}

				if (driver.findElements(By.xpath("//*[@id='reg_terms']"))
						.size() != 0) {

					if (driver
							.findElement(By.xpath("//*[@id='reg_terms']"))
							.getText()
							.equals("Please mark the checkbox to agree with the Terms of use.")) {

						System.out
								.println(userMap.get("userName").toString()
										+ "::"
										+ "Please mark the checkbox to agree with the Terms of use.");

						// continue;
						mapvalue = mapvalue
								+ " "
								+ "Please mark the checkbox to agree with the Terms of use.";
					}

				}

				// If user already exist,sometimes URL switch to register page,
				// if it is the case we can check the same and have the required
				// message

				if (currentURL.equals("http://www.adda52.com/register")) {
					System.out.println(userMap.get("userName").toString()
							+ " Already Registered");
					signUpMsgMap.put(userMap.get("userName").toString(),
							"Already Exist");

					mapvalue = mapvalue + " " + "Already Exist";

				}

				// If sign up gets successful...URL will get change and we can
				// have the messages as below

				if (currentURL
						.contains("http://www.adda52.com/successful-registration")) {
					System.out.println(userMap.get("userName").toString()
							+ " Registered Successfully");
					signUpMsgMap.put(userMap.get("userName").toString(),
							"Registered Successfully");
					mapvalue = mapvalue + " " + "Registered Successfully";

					// Code to check whether successfully signed up user has the
					// specified content page.
					String content = Common.readContent("SignUpContent");
					String UIContent = driver
							.findElement(
									By.xpath("//*[@id='wrapper']/section/div/article/div/div"))
							.getText();
					content = content.replaceAll("user",
							userMap.get("userName").toString()).replaceAll(
							"email_addr", userMap.get("email").toString());

					UIContent = UIContent.replaceAll("\\r|\\n", "");

					// System.out.println("############" + UIContent
					// + "#####################");
					// System.out.println("****" + content + "****");
					Assert.assertTrue(UIContent.contentEquals(content));
					// Write result to excel here instead of system.out
					// System.out
					// .println("&&&&&&&&&&&&&&&&&&&&&&&Content Matched##########################");

				}
				System.out.println("Returned VALUE" + mapvalue);
				signUpMsgMap.put(userMap.get("userName").toString(),
						mapvalue.toString());

			}
			utility.writeExcelSignUpMessage(signUpMsgMap);
		} catch (Exception e) {
			e.printStackTrace();
		}
		// fail("Not yet implemented");
	}

	// Testing Site Links From Excel
	// @Test
	public void SiteLinks() throws IOException {
		// Start
		String mapvalue = "";
		WebDriverWait wait = new WebDriverWait(driver, 10);
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		HashMap<String, String> urlResult = new HashMap<String, String>();
		// End

		// ExcelUtiltiy.readUserData() will read the entire excel and put each
		// row of excel in hashmp and then add the hashmap to the List
		// We will then fetch the list here

		ArrayList<String> linkList = (ArrayList<String>) utility.readLinks();
		if (driver.findElements(By.xpath("html/body/div[3]/div/div/img"))
				.size() != 0) {
			driver.findElement(By.xpath("html/body/div[3]/div/div/img"))
					.click();

		}
		driver.findElement(By.xpath("//*[@id='username']")).click();
		driver.findElement(By.xpath("//*[@id='password']")).clear();
		driver.findElement(By.id("username")).sendKeys("rahulsh");
		driver.findElement(By.id("password")).clear();
		driver.findElement(By.id("password")).sendKeys("gauss123");
		driver.findElement(By.id("btn-login")).click();

		for (String url : linkList) {
			driver.get(url);
			if (driver.getCurrentUrl().equals(url)) {
				urlResult.put(url, "PASS");
			} else {
				urlResult.put(url, "FAIL");
			}

		}
		utility.readExcelTestCases("Links.xls");
		utility.writeExcelTestResult(urlResult, "Links.xls", 1);

		// try {
		// FileInputStream file=new FileInputStream(new
		// File("D:\\Adda52-Automation\\Adda52\\Links.xls"));
		// FileOutputStream outFile=new FileOutputStream(new
		// File("D:\\Adda52-Automation\\Adda52\\Links.xls"));
		// HSSFWorkbook workbook=new HSSFWorkbook(file);
		// HSSFSheet sheet=workbook.getSheetAt(0);
		// HSSFCell cell=null;
		// int s=sheet.getLastRowNum()+1;
		// for(int i=0; i<s; i++){
		// cell=sheet.getRow(i).getCell(0);
		// String url=cell.toString();
		// driver.get(url);
		// try {
		// Thread.sleep(10000);
		// } catch (InterruptedException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		// String urlnew=driver.getCurrentUrl().toString();
		// HSSFRow row=sheet.getRow(i);
		// HSSFCell cellresult=row.createCell(3);
		// if(url==urlnew){
		// cellresult.setCellValue("Pass");
		// }else{
		// cellresult.setCellValue("fail");
		// }
		// workbook.write(outFile);
		// }
		// file.close();
		// outFile.close();
		// }
		// catch (FileNotFoundException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// } catch (IOException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// } finally {
		// driver.quit();
		// }
	}

	@After
	public void tearDown() throws Exception {
	}
}
