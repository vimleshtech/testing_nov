//=======================================================================================
// --- Created By: Rahul Shrivastava
// --- Created Date: 16-06-2014
// --- Modified Date: 
// --- Modified By: 
//=======================================================================================

package testcases;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import utilities.BrowserStartup;
import utilities.Common;


public class SignUp extends BrowserStartup  {

	private WebDriver driver;
	  private String baseUrl;
	  private boolean acceptNextAlert = true;
	  private StringBuffer verificationErrors = new StringBuffer();
		private Map<String, String> innerResultMap = null;
		private Common common = new Common();

	  @Before
	  public void SignUp() throws Exception {

			driver = new FirefoxDriver();
			baseUrl = "http://adda52.com/";

			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			driver.get(baseUrl + "/");

	}

//## Purpose: To verify that the SignUp page should open on selecting the SIGNUP from the home page.
	  @Test
	  public void testTC0001() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.id("btnSignUp")).click();
	    try {
	      assertTrue(isElementPresent(By.id("btnSignUp")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("btnSignUp")).click();
	    driver.get(baseUrl + "/register");
	    
	    driver.findElement(By.id("btnSignUp")).click();
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='wrapper']/section/div/article/div")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='userSignup']/div[2]/div[1]/label")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//form[@id='userSignup']/div[2]/div[2]/label")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//form[@id='userSignup']/div[2]/div[3]/label")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//form[@id='userSignup']/div[2]/div[4]/label")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//form[@id='userSignup']/div[2]/div[5]/label")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//form[@id='userSignup']/div[2]/div[6]")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.id("btn-signup")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    
	/* MY CODE 
	    // To verify Birth Year List
	   driver.findElement(By.xpath("//*[@id='dobyear']")).getText();
	   List<WebElement> listOfOptions = driver.findElements(By.xpath("//*[@id='dobyear']")); 
     
	   //print the options/values of the drop down list.
      for(WebElement item : listOfOptions)
      {
        System.out.println(item.getText());
      } 
      String[] DOB = {"Select","1900","1901","1902","1903","1904","1905","1906","1907","1908","1909","1910","1911","1912","1913","1914","1915","1916","1917","1918","1919","1920","1921","1922","1923","1924","1925","1926","1927","1928","1929","1930","1931","1932","1933","1934","1935","1936","1937","1938","1939","1940","1941","1942","1943","1944","1945","1946","1947","1948","1949","1950","1951","1952","1953","1954","1955","1956","1957","1958","1959","1960","1961","1962","1963","1964","1965","1966","1967","1968","1969","1970","1971","1972","1973","1974","1975","1976","1977","1978","1979","1980","1981","1982","1983","1984","1985","1986","1987","1988","1989","1990","1991","1992","1993","1994","1995","1996","1997","1998","1999","2000","2001"
      }; 
      WebElement dropdown = driver.findElement(By.xpath("//*[@id='dobyear']"));  
              Select select = new Select(dropdown);  

              List<WebElement> options = select.getOptions();  
              for(WebElement we:options)  
              {  
               for (int i=0; i<DOB.length; i++){
                   if (we.getText().equals(DOB[i])){
                   System.out.println("Matched");
                   } 
                   else{
                   System.out.println("Not Matched");
                 }
               }
              }
	  }
                */
     
	    
	 // To verify Birth Year List
	    driver.findElement(By.xpath("//*[@id='dobyear']")).getText();
	    List<WebElement> listOfOptions = driver.findElements(By.xpath("//*[@id='dobyear']")); 
	    String[] optionValues = new String[]{"Select","1900","1901","1902","1903","1904","1905","1906","1907","1908","1909","1910","1911","1912","1913","1914","1915","1916","1917","1918","1919","1920","1921","1922","1923","1924","1925","1926","1927","1928","1929","1930","1931","1932","1933","1934","1935","1936","1937","1938","1939","1940","1941","1942","1943","1944","1945","1946","1947","1948","1949","1950","1951","1952","1953","1954","1955","1956","1957","1958","1959","1960","1961","1962","1963","1964","1965","1966","1967","1968","1969","1970","1971","1972","1973","1974","1975","1976","1977","1978","1979","1980","1981","1982","1983","1984","1985","1986","1987","1988","1989","1990","1991","1992","1993","1994","1995","1996","1997","1998","1999","2000","2001"};


	    boolean flag = false;
	    //print the options/values of the drop down list.
	    for(WebElement item : listOfOptions)
	    {
	           flag = false;
	           System.out.println("GET VALUES: "+ item.getText());
	           for(String option :optionValues){
	              System.out.println("Matched Value: "+ option.toString());
	                   if(item.getText().equals(option.toString())){
	                         System.out.println("Matched Vaulue: "+ option.toString());
	                           flag = true;
	                           break;
	                           
	                   }
	                   
	           }
	           
	           if(flag== false){
	                   break;
	           }

	           
	    }

	    if(flag == false){
	           System.out.println("Test Fail");
	    }else{
	           System.out.println("Test Pass");
	    }
	  }
	     

//## Purpose: To verify that the error message should appear on leaving all the fields blank.
	  
	  @Test
	  public void testTC0003() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.linkText("Adda52.com")).click();
	    try {
	      assertTrue(isElementPresent(By.id("btnSignUp")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("btnSignUp")).click();
	    driver.findElement(By.id("btn-signup")).click();
	    try {
	      assertTrue(isElementPresent(By.id("btn-signup")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("btn-signup")).click();
	    try {
	      assertEquals("The User Name field is required.", driver.findElement(By.id("reg_uname")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertEquals("The Password field is required.", driver.findElement(By.id("reg_pwd")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertEquals("The Email field is required.", driver.findElement(By.id("reg_email")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertEquals("The Birth Year field is required.", driver.findElement(By.id("reg_dobyear")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertEquals("The Gender field is required.", driver.findElement(By.id("reg_gender")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertEquals("Please mark the checkbox to agree with the Terms of use.", driver.findElement(By.id("reg_terms")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

//## Purpose: To verify that the error message should appear on entering the symbol ($,@,* or # ).

	  @Test
	  public void testTC0005() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.id("btnSignUp")).click();
	    driver.findElement(By.id("reg_username")).clear();
	    driver.findElement(By.id("reg_username")).sendKeys("test@123");
	    driver.findElement(By.id("btn-signup")).click();
	    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | name=fbMainContainer | ]]
	    // driver.findElement(By.id("fbInspectButton")).click();
	    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | null | ]]
	    driver.findElement(By.id("reg_uname")).click();
	    try {
	      assertEquals("The User Name field may only contain alphanumeric characters.", driver.findElement(By.id("reg_uname")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

//## Purpose: To verify that the error message should appear on entering the SYMBOL ($,@,* ,#..)+NUMERIC(1,2..) values.
	  @Test
	  public void testTC0007() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.id("btnSignUp")).click();
	    driver.findElement(By.id("reg_username")).clear();
	    driver.findElement(By.id("reg_username")).sendKeys("12345@#&");
	    driver.findElement(By.id("btn-signup")).click();
	    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | name=fbMainContainer | ]]
	    // driver.findElement(By.id("fbInspectButton")).click();
	    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | null | ]]
	    driver.findElement(By.id("reg_uname")).click();
	    try {
	      assertEquals("The User Name field may only contain alphanumeric characters.", driver.findElement(By.id("reg_uname")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

//## Purpose: To verify that the error message should appear on entering the Numeric values(1234567890).
	  @Test
	  public void testTC0008() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.id("btnSignUp")).click();
	    driver.findElement(By.id("reg_username")).click();
	    driver.findElement(By.id("reg_username")).clear();
	    driver.findElement(By.id("reg_username")).sendKeys("1234567894");
	    driver.findElement(By.id("btn-signup")).click();
	  }

//## Purpose: To verify that the error message should appear on entering the existing User name.
	  @Test
	  public void testTC0009() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.id("btnSignUp")).click();
	    driver.findElement(By.id("reg_username")).clear();
	    driver.findElement(By.id("reg_username")).sendKeys("rahulsh");
	    driver.findElement(By.id("btn-signup")).click();
	    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | name=fbMainContainer | ]]
	    // driver.findElement(By.id("fbInspectButton")).click();
	    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | null | ]]
	    driver.findElement(By.id("reg_uname")).click();
	    try {
	      assertEquals("User Name already exists. Please use a different one.", driver.findElement(By.id("reg_uname")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

//## Purpose: To verify that the error message should appear on entering 'adda' as a user name
	  @Test
	  public void testTC0010() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.id("btnSignUp")).click();
	  
	  // To check Auto focus
	   if( driver.findElement(By.id("reg_username")).isSelected())
	   {
	   	driver.findElement(By.id("reg_username")).sendKeys("abc");
	   	
	   }
	   
	  else
	  {
		   System.out.println("Test Case Is Failed");
	  }
	  
	  // To check Water mark text disappears on click
	  driver.findElement(By.id("btnSignUp")).click();
	  driver.findElement(By.id("reg_username")).click();
	  
	  if(driver.findElement(By.id("reg_username")).getText().isEmpty())
			   {
		   System.out.println("Test Case Passed");
			   }
	  else 
	  {
		   System.out.println("Test Case Failed");
	  }
		   
	  }
	  
//## Purpose: To verify that the error message should appear on entering minimum(or upto) 2 characters.
	  @Test
	  public void testTC0011() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.id("btnSignUp")).click();
	    driver.findElement(By.id("reg_username")).clear();
	    driver.findElement(By.id("reg_username")).sendKeys("r");
	    driver.findElement(By.id("btn-signup")).click();
	    driver.findElement(By.id("reg_uname")).click();
	    try {
	      assertEquals("The User Name field must be minimum 3 and maximum 20 characters in length.", driver.findElement(By.id("reg_uname")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("reg_username")).click();
	    driver.findElement(By.id("reg_username")).clear();
	    driver.findElement(By.id("reg_username")).sendKeys("rs");
	    driver.findElement(By.id("btn-signup")).click();
	    driver.findElement(By.id("reg_uname")).click();
	    try {
	      assertEquals("The User Name field must be minimum 3 and maximum 20 characters in length.", driver.findElement(By.id("reg_uname")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

//## Purpose: To verify that the error message should appear on entering the 21 characters value(or more than 21).
	  @Test
	  public void testTC0012() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.id("btnSignUp")).click();
	    driver.findElement(By.id("reg_username")).clear();
	    driver.findElement(By.id("reg_username")).sendKeys("qawsedrftgyhujikolpqa");
	    driver.findElement(By.id("btn-signup")).click();
	    driver.findElement(By.id("reg_uname")).click();
	    try {
	      assertEquals("The User Name field must be minimum 3 and maximum 20 characters in length.", driver.findElement(By.id("reg_uname")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

//## Purpose: To verify that the error message should appear when Password field is left blank
	  @Test
	  public void testTC0015() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.id("btnSignUp")).click();
	    driver.findElement(By.id("reg_username")).clear();
	    driver.findElement(By.id("reg_username")).sendKeys("testingsela");
	    driver.findElement(By.name("email")).clear();
	    driver.findElement(By.name("email")).sendKeys("testi@gauuss.com");
	    new Select(driver.findElement(By.id("dobyear"))).selectByVisibleText("1985");
	    driver.findElement(By.id("gender")).click();
	    new Select(driver.findElement(By.id("gender"))).selectByVisibleText("Male");
	    driver.findElement(By.name("terms")).click();
	    driver.findElement(By.id("btn-signup")).click();
	    driver.findElement(By.id("reg_pwd")).click();
	    try {
	      assertEquals("The Password field is required.", driver.findElement(By.id("reg_pwd")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

//## Purpose: To verify that the error message should appear on entering the symbol ($,@,* or #).
	  @Test
	  public void testTC0016() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.id("btnSignUp")).click();
	    driver.findElement(By.id("reg_username")).clear();
	    driver.findElement(By.id("reg_username")).sendKeys("testingsela");
	    driver.findElement(By.id("reg_password")).clear();
	    driver.findElement(By.id("reg_password")).sendKeys("test@#$&qw");
	    driver.findElement(By.name("email")).clear();
	    driver.findElement(By.name("email")).sendKeys("testi@gauss.com");
	    new Select(driver.findElement(By.id("dobyear"))).selectByVisibleText("1984");
	    new Select(driver.findElement(By.id("gender"))).selectByVisibleText("Male");
	    driver.findElement(By.cssSelector("option[value=\"male\"]")).click();
	    driver.findElement(By.name("terms")).click();
	    driver.findElement(By.id("btn-signup")).click();
	  }

//## To verify that the error message should appear on entering only symbol ($,@,* or #) values-minimum 8 to 20 characters in length.
	  @Test
	  public void testTC0017() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.id("btnSignUp")).click();
	    driver.findElement(By.id("reg_username")).clear();
	    driver.findElement(By.id("reg_username")).sendKeys("testselb");
	    driver.findElement(By.id("reg_password")).clear();
	    driver.findElement(By.id("reg_password")).sendKeys("@@@@@@@@@@");
	    driver.findElement(By.name("email")).clear();
	    driver.findElement(By.name("email")).sendKeys("ts@gau.com");
	    new Select(driver.findElement(By.id("dobyear"))).selectByVisibleText("1984");
	    driver.findElement(By.cssSelector("option[value=\"1984\"]")).click();
	    new Select(driver.findElement(By.id("gender"))).selectByVisibleText("Male");
	    driver.findElement(By.name("terms")).click();
	    driver.findElement(By.id("btn-signup")).click();
	    driver.findElement(By.id("reg_pwd")).click();
	    try {
	      assertEquals("The Password field may only contain alphanumeric characters.", driver.findElement(By.id("reg_pwd")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

//## Purpose: To verify that the error message should appear on entering minimum (or upto) 7 characters.
	  @Test
	  public void testTC0018() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.id("btnSignUp")).click();
	    driver.findElement(By.id("reg_username")).clear();
	    driver.findElement(By.id("reg_username")).sendKeys("testy");
	    driver.findElement(By.id("reg_password")).clear();
	    driver.findElement(By.id("reg_password")).sendKeys("abcha12");
	    driver.findElement(By.name("email")).clear();
	    driver.findElement(By.name("email")).sendKeys("tra@gau.com");
	    driver.findElement(By.id("dobyear")).click();
	    new Select(driver.findElement(By.id("dobyear"))).selectByVisibleText("1984");
	    new Select(driver.findElement(By.id("gender"))).selectByVisibleText("Male");
	    driver.findElement(By.name("terms")).click();
	    driver.findElement(By.id("btn-signup")).click();
	    driver.findElement(By.id("reg_pwd")).click();
	    try {
	      assertEquals("The Password field must be minimum 8 and maximum 20 characters in length.", driver.findElement(By.id("reg_pwd")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

//## Purpose: To verify that the error message should appear on entering the 21 characters value (or more than 21).
	  @Test
	  public void testTC0019() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.id("btnSignUp")).click();
	    driver.findElement(By.id("reg_username")).clear();
	    driver.findElement(By.id("reg_username")).sendKeys("testy");
	    driver.findElement(By.id("reg_password")).clear();
	    driver.findElement(By.id("reg_password")).sendKeys("qawsedrftgyhujikolpqa");
	    driver.findElement(By.name("email")).clear();
	    driver.findElement(By.name("email")).sendKeys("dd@gau.com");
	    new Select(driver.findElement(By.id("dobyear"))).selectByVisibleText("1984");
	    new Select(driver.findElement(By.id("gender"))).selectByVisibleText("Male");
	    driver.findElement(By.name("terms")).click();
	    driver.findElement(By.id("btn-signup")).click();
	    driver.findElement(By.id("reg_pwd")).click();
	    try {
	      assertEquals("The Password field must be minimum 8 and maximum 20 characters in length.", driver.findElement(By.id("reg_pwd")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

	  
//## Purpose: To verify that error message should appear when entered password is same as user name.
	  @Test
	  public void testTC0020() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.id("btnSignUp")).click();
	    driver.findElement(By.id("reg_username")).clear();
	    driver.findElement(By.id("reg_username")).sendKeys("testselaa");
	    driver.findElement(By.id("reg_password")).clear();
	    driver.findElement(By.id("reg_password")).sendKeys("testselaa");
	    driver.findElement(By.name("email")).clear();
	    driver.findElement(By.name("email")).sendKeys("ts@ff.com");
	    driver.findElement(By.id("dobyear")).click();
	    new Select(driver.findElement(By.id("dobyear"))).selectByVisibleText("1984");
	    new Select(driver.findElement(By.id("gender"))).selectByVisibleText("Male");
	    driver.findElement(By.name("terms")).click();
	    driver.findElement(By.id("btn-signup")).click();
	    driver.findElement(By.id("reg_pwd")).click();
	    try {
	      assertEquals("The Password field should not be same as User Name.", driver.findElement(By.id("reg_pwd")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

	  
//## Purpose: To verify that the error message should appear when email field is left blank.
	  @Test
	  public void testTC0022() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.id("btnSignUp")).click();
	    driver.findElement(By.id("reg_username")).clear();
	    driver.findElement(By.id("reg_username")).sendKeys("testingsela");
	    driver.findElement(By.id("reg_password")).clear();
	    driver.findElement(By.id("reg_password")).sendKeys("testingaaa");
	    driver.findElement(By.id("dobyear")).click();
	    new Select(driver.findElement(By.id("dobyear"))).selectByVisibleText("1984");
	    new Select(driver.findElement(By.id("gender"))).selectByVisibleText("Male");
	    driver.findElement(By.cssSelector("option[value=\"male\"]")).click();
	    driver.findElement(By.name("terms")).click();
	    driver.findElement(By.id("btn-signup")).click();
	    driver.findElement(By.id("reg_email")).click();
	    try {
	      assertEquals("The Email field is required.", driver.findElement(By.id("reg_email")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

	  
//## Purpose: To verify that the error message should appear when wrong email address is entered.
	  @Test
	  public void testTC0023() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.id("btnSignUp")).click();
	    driver.findElement(By.id("reg_username")).clear();
	    driver.findElement(By.id("reg_username")).sendKeys("tesinggsel");
	    driver.findElement(By.id("reg_password")).clear();
	    driver.findElement(By.id("reg_password")).sendKeys("asdfrgthy1");
	    driver.findElement(By.name("email")).clear();
	    driver.findElement(By.name("email")).sendKeys("asv.com");
	    new Select(driver.findElement(By.id("dobyear"))).selectByVisibleText("1984");
	    new Select(driver.findElement(By.id("gender"))).selectByVisibleText("Male");
	    driver.findElement(By.name("terms")).click();
	    driver.findElement(By.id("btn-signup")).click();
	    driver.findElement(By.id("reg_email")).click();
	    try {
	      assertEquals("The Email field must contain a valid email address.", driver.findElement(By.id("reg_email")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

//## Purpose: To verify that email character length should be restricted
	  @Test
	  public void testTC0025() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.id("btnSignUp")).click();
	    driver.findElement(By.id("reg_username")).clear();
	    driver.findElement(By.id("reg_username")).sendKeys("testingselb");
	    driver.findElement(By.id("reg_password")).clear();
	    driver.findElement(By.id("reg_password")).sendKeys("qawsedrftg1");
	    driver.findElement(By.name("email")).click();
	    driver.findElement(By.name("email")).clear();
	    driver.findElement(By.name("email")).sendKeys("xadaasdasdasdasdsdasdasdasdasdasdasddfsdfsdfsdfsfdsdasdasdasdasdasdasdasdasdadsdfsdfsaaaaaaadf@ya.com");
	    new Select(driver.findElement(By.id("dobyear"))).selectByVisibleText("1984");
	    new Select(driver.findElement(By.id("gender"))).selectByVisibleText("Female");
	    driver.findElement(By.name("terms")).click();
	    driver.findElement(By.id("btn-signup")).click();
	    driver.findElement(By.id("reg_email")).click();
	    try {
	      assertEquals("The Email field must contain a valid email address.", driver.findElement(By.id("reg_email")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

	  
//## Purpose: To verify that the error message should appear when Birth Year is not selected.
	  @Test
	  public void testTC0027() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.id("btnSignUp")).click();
	    driver.findElement(By.id("reg_username")).clear();
	    driver.findElement(By.id("reg_username")).sendKeys("testingyoua");
	    driver.findElement(By.id("reg_password")).clear();
	    driver.findElement(By.id("reg_password")).sendKeys("testing091");
	    driver.findElement(By.name("email")).clear();
	    driver.findElement(By.name("email")).sendKeys("testingyu@gauss.com");
	    new Select(driver.findElement(By.id("gender"))).selectByVisibleText("Male");
	    driver.findElement(By.cssSelector("option[value=\"male\"]")).click();
	    driver.findElement(By.name("terms")).click();
	    driver.findElement(By.id("btn-signup")).click();
	    driver.findElement(By.id("reg_dobyear")).click();
	    try {
	      assertEquals("The Birth Year field is required.", driver.findElement(By.id("reg_dobyear")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

	  
//## Purpose: To verify that the error message should appear when Gender is not selected.
	  @Test
	  public void testTC0029() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.id("btnSignUp")).click();
	    driver.findElement(By.id("reg_username")).clear();
	    driver.findElement(By.id("reg_username")).sendKeys("testingyou");
	    driver.findElement(By.id("reg_password")).clear();
	    driver.findElement(By.id("reg_password")).sendKeys("rs@gauss.com");
	    driver.findElement(By.name("email")).clear();
	    driver.findElement(By.name("email")).sendKeys("gauss.rs@gauss.com");
	    new Select(driver.findElement(By.id("dobyear"))).selectByVisibleText("1984");
	    driver.findElement(By.name("terms")).click();
	    driver.findElement(By.id("btn-signup")).click();
	    driver.findElement(By.id("reg_gender")).click();
	    try {
	      assertEquals("The Gender field is required.", driver.findElement(By.id("reg_gender")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

	  
//## Purpose: To verify that the error message should appear when Check(tick) Box is not selected.
	  @Test
	  public void testTC0031() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.id("btnSignUp")).click();
	    driver.findElement(By.id("reg_username")).clear();
	    driver.findElement(By.id("reg_username")).sendKeys("testingyou");
	    driver.findElement(By.id("password_clear")).clear();
	    driver.findElement(By.id("password_clear")).sendKeys("tesrtyu12");
	    driver.findElement(By.name("email")).clear();
	    driver.findElement(By.name("email")).sendKeys("gauss.rs@gauss.com");
	    driver.findElement(By.id("dobyear")).click();
	    new Select(driver.findElement(By.id("dobyear"))).selectByVisibleText("1984");
	    new Select(driver.findElement(By.id("gender"))).selectByVisibleText("Male");
	    driver.findElement(By.id("btn-signup")).click();
	    driver.findElement(By.id("reg_terms")).click();
	    try {
	      assertEquals("Please mark the checkbox to agree with the Terms of use.", driver.findElement(By.id("reg_terms")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }
//## Purpose: To check the auto-focus in SignUp --> User Name field
	  @Test
	  public void testTC0035() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.xpath("html/body/div[1]/div/div/img")).click();
	    
	    if (driver.findElement(By.xpath("//*[@id='reg_username']")).isSelected()){
	    	System.out.println("Test Case Has Passed");
	    }
	    else {
	    	System.out.println("Test Case Has Failed");
	    }
	  }


//## Purpose: To verify that the error message should appear on leaving all the fields blank.
	  @Test
	  public void testTC0036() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.id("slider_signup")).click();
	    try {
	      assertTrue(isElementPresent(By.id("slider_signup")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("btn-signup")).click();
	    driver.findElement(By.id("reg_uname")).click();
	    try {
	      assertEquals("The User Name field is required.", driver.findElement(By.id("reg_uname")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("reg_pwd")).click();
	    try {
	      assertEquals("The Password field is required.", driver.findElement(By.id("reg_pwd")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("reg_email")).click();
	    try {
	      assertEquals("The Email field is required.", driver.findElement(By.id("reg_email")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("reg_dobyear")).click();
	    try {
	      assertEquals("The Birth Year field is required.", driver.findElement(By.id("reg_dobyear")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("reg_gender")).click();
	    try {
	      assertEquals("The Gender field is required.", driver.findElement(By.id("reg_gender")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("reg_terms")).click();
	    try {
	      assertEquals("Please mark the checkbox to agree with the Terms of use.", driver.findElement(By.id("reg_terms")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

//## Purpose: To check that Water-mark Text disappears on clicking through mouse
	  @Test
	  public void testTC0037() throws Exception {
		driver.navigate().to(baseUrl + "/");
		    driver.findElement(By.xpath("html/body/div[1]/div/div/img")).click();
		    driver.findElement(By.xpath("//*[@id='reg_username']")).clear();
		    
		    if (driver.findElement(By.xpath("//*[@id='reg_username']")).getText().equals("")){
		    	System.out.println("Test Case Has Passed");
		    }
		    else {
		    	System.out.println("Test Case Has Failed");
		    }
	  }

//## To verify Slider - User Name field validation
	  @Test
	  public void testTC0038TC0045() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.xpath("html/body/div[1]/div/div/img")).click();
	    driver.findElement(By.id("reg_username")).click();
	    driver.findElement(By.id("reg_username")).clear();
	    driver.findElement(By.id("reg_username")).sendKeys("@#$&***");
	    driver.findElement(By.id("btn-signup")).click();
	    driver.findElement(By.id("reg_uname")).click();
	    try {
	      assertEquals("The User Name field may only contain alphanumeric characters.", driver.findElement(By.id("reg_uname")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("reg_username")).click();
	    driver.findElement(By.id("reg_username")).clear();
	    driver.findElement(By.id("reg_username")).sendKeys("@#$test");
	    driver.findElement(By.id("btn-signup")).click();
	    try {
	      assertEquals("The User Name field may only contain alphanumeric characters.", driver.findElement(By.id("reg_uname")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("reg_username")).click();
	    driver.findElement(By.id("reg_username")).clear();
	    driver.findElement(By.id("reg_username")).sendKeys("test@#$*");
	    driver.findElement(By.id("btn-signup")).click();
	    try {
	      assertEquals("The User Name field may only contain alphanumeric characters.", driver.findElement(By.id("reg_uname")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("reg_username")).clear();
	    driver.findElement(By.id("reg_username")).sendKeys("@#$*1234");
	    driver.findElement(By.id("btn-signup")).click();
	    driver.findElement(By.id("reg_uname")).click();
	    try {
	      assertEquals("The User Name field may only contain alphanumeric characters.", driver.findElement(By.id("reg_uname")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("reg_username")).clear();
	    driver.findElement(By.id("reg_username")).sendKeys("1234@$*&");
	    driver.findElement(By.id("btn-signup")).click();
	    try {
	      assertEquals("The User Name field may only contain alphanumeric characters.", driver.findElement(By.id("reg_uname")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("reg_username")).clear();
	    driver.findElement(By.id("reg_username")).sendKeys("1234567812312");
	    driver.findElement(By.id("btn-signup")).click();
	    try {
		      assertEquals("The User Name field may only contain alphanumeric characters.", driver.findElement(By.id("reg_uname")).getText());
		    } catch (Error e) {
		      verificationErrors.append(e.toString());
		    }
	    driver.findElement(By.id("reg_username")).clear();
	    driver.findElement(By.id("reg_username")).sendKeys("adda");
	    driver.findElement(By.id("btn-signup")).click();
	    try {
		      assertEquals("User Name already exists. Please use a different one..", driver.findElement(By.id("reg_uname")).getText());
		    } catch (Error e) {
		      verificationErrors.append(e.toString());
		    }
	    driver.findElement(By.id("reg_username")).clear();
	    driver.findElement(By.id("reg_username")).sendKeys("te");
	    driver.findElement(By.id("btn-signup")).click();
	    try {
	      assertEquals("The User Name field must be minimum 3 and maximum 20 characters in length.", driver.findElement(By.id("reg_uname")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("reg_username")).clear();
	    driver.findElement(By.id("reg_username")).sendKeys("qawsedrftgyhujikolpqa");
	    driver.findElement(By.id("btn-signup")).click();
	    try {
	      assertEquals("The User Name field must be minimum 3 and maximum 20 characters in length.", driver.findElement(By.id("reg_uname")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

	//## Purpose: Slider --> SignUp To verify that the Water-mark text inside the Password field disappears on click.
	  @Test
	  public void testTC0047() throws Exception {
		  driver.navigate().to(baseUrl + "/");
		    driver.findElement(By.xpath("html/body/div[1]/div/div/img")).click();
		    driver.findElement(By.xpath("//*[@id='password_clear']")).clear();
		    
		    if (driver.findElement(By.xpath("//*[@id='password_clear']")).getText().equals("")){
		    	System.out.println("Test Case Has Passed");
		    }
		    else{
		    	System.out.println("Test Case Has Failed");
		    }
	  }

	//## To verify Slider - Password field validation
	  @Test
	  public void testTC0048TC0053() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.xpath("html/body/div[1]/div/div/img")).click();
	    
	    driver.findElement(By.xpath("//*[@id='btn-signup']")).click();
	    try {
	      assertEquals("The Password field is required.", driver.findElement(By.id("reg_pwd")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("password_clear")).clear();
	    driver.findElement(By.id("reg_password")).sendKeys("@#$&*");
	    driver.findElement(By.id("btn-signup")).click();
	    try {
	      assertEquals("The Password field must be minimum 8 and maximum 20 characters in length.", driver.findElement(By.id("reg_pwd")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("reg_password")).click();
	    driver.findElement(By.id("reg_password")).clear();
	    driver.findElement(By.id("reg_password")).sendKeys("@#$%^&*@#@$#%#$%#$%");
	    driver.findElement(By.id("btn-signup")).click();
	    driver.findElement(By.id("reg_pwd")).click();
	    try {
	      assertEquals("The Password field may only contain alphanumeric characters.", driver.findElement(By.id("reg_pwd")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("reg_password")).clear();
	    driver.findElement(By.id("reg_password")).sendKeys("testing");
	    driver.findElement(By.id("btn-signup")).click();
	    try {
	      assertEquals("The Password field must be minimum 8 and maximum 20 characters in length.", driver.findElement(By.id("reg_pwd")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("reg_password")).clear();
	    driver.findElement(By.id("reg_password")).sendKeys("qawsedrftgyhujikolpqa");
	    driver.findElement(By.id("btn-signup")).click();
	    try {
	      assertEquals("The Password field must be minimum 8 and maximum 20 characters in length.", driver.findElement(By.id("reg_pwd")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("reg_username")).clear();
	    driver.findElement(By.id("reg_username")).sendKeys("rahultestingaaa");
	    driver.findElement(By.id("reg_password")).clear();
	    driver.findElement(By.id("reg_password")).sendKeys("rahultestingaaa");
	    driver.findElement(By.id("btn-signup")).click();
	    try {
	      assertEquals("The Password field should not be same as User Name.", driver.findElement(By.id("reg_pwd")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }
	  
		//## To verify Slider - Email field validation
	  @Test
	  public void testTC0055TC0059() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.xpath("html/body/div[1]/div/div/img")).click();
	    
	    driver.findElement(By.id("btn-signup")).click();
	    try {
	      assertEquals("The Email field is required.", driver.findElement(By.id("reg_email")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("email")).clear();
	    driver.findElement(By.id("email")).sendKeys("akjshdashd@asdasd");
	    driver.findElement(By.id("btn-signup")).click();
	    try {
	      assertEquals("The Email field must contain a valid email address.", driver.findElement(By.id("reg_email")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("email")).clear();
	    driver.findElement(By.id("email")).sendKeys("rahul.shrivastava@gauss.com");
	    driver.findElement(By.id("email")).clear();
	    driver.findElement(By.id("email")).sendKeys("rahul.shrivastava@gaussnetworks.com");
	    driver.findElement(By.id("btn-signup")).click();
	    driver.findElement(By.id("email")).click();
	    driver.findElement(By.id("email")).clear();
	    driver.findElement(By.id("email")).sendKeys("rahulsh@gauss.com");
	    driver.findElement(By.id("btn-signup")).click();
	    driver.findElement(By.id("email")).clear();
	    driver.findElement(By.id("email")).sendKeys("ssfssdsdfsdfsdfsdfsdasdddddddddddddddddddddfsdfsdfsdf@yaaaaaaaaaaaaaaaaaaaaaaaaa");
	    driver.findElement(By.id("btn-signup")).click();
	    try {
	      assertEquals("The Email field must contain a valid email address.", driver.findElement(By.id("reg_email")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

	  //## Purpose: Slider --> SignUp: To verify that the Check-box is selectable for Terms Of Use
	  @Test	  
	  public void testTC0065() throws Exception {
			driver.navigate().to(baseUrl + "/");
		    driver.findElement(By.xpath("html/body/div[1]/div/div/img")).click();
		    
		    if (driver.findElement(By.xpath("//*[@id='agree']")).isEnabled()){
		    	driver.findElement(By.xpath("//*[@id='agree']")).click();
		    	System.out.println("Check Box is selectable");
		    }
		    else{
		    	System.out.println("Check box is not selectable");
		    }
		    
	  }
		    
		    
	  //## Purpose: To verify that the Sign Up (footer) should appear in every page except Home page.
	  @Test
	  public void testTC0068() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.linkText("Adda52.com")).click();
	    driver.findElement(By.linkText("Promotions")).click();
	    driver.findElement(By.cssSelector("div.cntformbg.firepath-matching-node")).click();
	    try {
	      assertTrue(isElementPresent(By.cssSelector("div.cntformbg.firepath-matching-node")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.linkText("Customer Support")).click();
	    try {
	      assertTrue(isElementPresent(By.cssSelector("div.cntformbg.firepath-matching-node")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.linkText("Games")).click();
	    try {
	      assertTrue(isElementPresent(By.cssSelector("div.cntformbg.firepath-matching-node")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

	  
//## Purpose: Login | To verify that the error message should appear when all the fields are left blank.
	  @Test
	  public void testTC0103() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.linkText("Adda52.com")).click();
	    driver.findElement(By.id("password")).click();
	    driver.findElement(By.id("username")).click();
	    driver.findElement(By.id("password")).clear();
	    driver.findElement(By.id("password")).sendKeys("passwordonly");
	    driver.findElement(By.id("btn-login")).click();
	    try {
	      assertTrue(isElementPresent(By.id("userid_warn")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

	  
//## Purpose: Login | To verify that the error message should appear when only 'Password' field is left blank.
	  @Test
	  public void testTC0105() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.linkText("Adda52.com")).click();
	    driver.findElement(By.id("username")).clear();
	    driver.findElement(By.id("username")).sendKeys("tesingyou");
	    driver.findElement(By.id("btn-login")).click();
	    driver.findElement(By.id("pwd_warn")).click();
	    try {
	      assertTrue(isElementPresent(By.id("pwd_warn")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

	  
//## Purpose: Login | To verify that the error message should appear when 'Username/Email' is correct & 'Password' is wrong.
	  @Test
	  public void testTC0106() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.linkText("Adda52.com")).click();
	    driver.findElement(By.id("username")).clear();
	    driver.findElement(By.id("username")).sendKeys("rahulsh");
	    driver.findElement(By.id("password")).clear();
	    driver.findElement(By.id("password")).sendKeys("testingyous");
	    driver.findElement(By.id("btn-login")).click();
	    driver.findElement(By.id("pwd_warn")).click();
	    try {
	      assertTrue(isElementPresent(By.id("pwd_warn")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

	  
//## Purpose: To verify that the 'Email' box should open after clicking the 'Forgot Password?'.
	  @Test
	  public void testTC0114() throws Exception {
		driver.navigate().to(baseUrl + "/");
	    driver.findElement(By.linkText("Adda52.com")).click();
	    driver.findElement(By.linkText("Forgot Password")).click();
	    try {
	      assertTrue(isElementPresent(By.cssSelector("div..firepath-matching-node")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

	  
//## Purpose: Forgot Password Link
	  @Test
	  public void testTC0115TC0117() throws Exception {
		driver.navigate().to(baseUrl + "/");
		  driver.findElement(By.xpath("html/body/div[1]/div/div/img")).click();
	      driver.findElement(By.xpath("//*[@id='forgot_password']/a")).click();
	      
		  String myWindowHandle = driver.getWindowHandle();
	      driver.switchTo().window(myWindowHandle);
	      
	      driver.findElement(By.xpath("//*[@id='login-box']"));
	      driver.findElement(By.xpath("//*[@id='emailFP']")).clear();
	      driver.findElement(By.xpath("//*[@id='submit_fp']")).click();
	      
	      if(driver.findElement(By.xpath("//*[@id='pwd_warnFP']")).getText().equals("The Email field is required.")){
	    	  System.out.println("Test Case Has Passed");
	      }
	      else{
	    	  System.out.println("Test Case Has Failed");
	      }
	      
	      driver.findElement(By.xpath("//*[@id='emailFP']")).clear();
	      driver.findElement(By.xpath("//*[@id='emailFP']")).sendKeys("jsagfjksgadf@asdfadsff");
	      driver.findElement(By.xpath("//*[@id='submit_fp']")).click();
	      if(driver.findElement(By.xpath("//*[@id='pwd_warnFP']")).getText().equals("Enter a valid email address.")){
	    	  System.out.println("Pass");
	      }
	      else{
	    	  System.out.println("Fail");
	      }
	      driver.findElement(By.xpath("//*[@id='emailFP']")).clear();
	      driver.findElement(By.xpath("//*[@id='emailFP']")).sendKeys("samarthtest@gauss.com");
	      driver.findElement(By.xpath("//*[@id='submit_fp']")).click();
	      
	      
	      Thread.sleep(15000);
	      
	      if(driver.findElement(By.xpath("//*[@id='pwd_warnFP']")).getText().equals("Your Password has been sent.")){
	    	  System.out.println("Pass");
	      }
	      else{
	    	  System.out.println("Fail");
	      }
	  }

	  
//## Purpose: To verify that the 'Log out' option should appear on top of the screen after log in.
	  @Test
	  public void testTC0123TC0125() throws Exception {
			driver.navigate().to(baseUrl + "/");
		    driver.findElement(By.id("username")).click();
		    driver.findElement(By.id("username")).clear();
		    driver.findElement(By.id("username")).sendKeys("rahulsh");
		    driver.findElement(By.id("password")).clear();
		    driver.findElement(By.id("password")).sendKeys("gauss123");
		    driver.findElement(By.id("btn-login")).click();
		    try {
		      assertTrue(isElementPresent(By.cssSelector("#logout > img")));
		    } catch (Error e) {
		      verificationErrors.append(e.toString());
		    }
		    driver.findElement(By.cssSelector("#logout > img")).click();
		    
		    String Current_URL = driver.getCurrentUrl();
		    
	    if (Current_URL == "http://adda52.org/logout"){
	    	System.out.println("Test Case Passed.");
	    }
	    else
	    {
	    	System.out.println("Test Case Failed.");
	    }
	    
	  }


	  @Test
	  public void testTC0110() throws Exception {

			driver.navigate().to(baseUrl + "/");
			driver.findElement(By.xpath("html/body/div[1]/div/div/img")).click();
		    
		    String[] username ={"rahulsh","rahulsh","rahulsh","rahulsh","rahulsh","rahulsh"};
		    String[] password ={"aaaaaaaa","bdddddd","ccccccc","dddddd","eeeeeee","feeeeee"};
		    
		    for (int indexTimes = 0; indexTimes < username.length - 1; indexTimes++)
		    {
			    driver.findElement(By.id("username")).clear();
			    driver.findElement(By.id("username")).sendKeys(username[indexTimes]);
			    driver.findElement(By.id("password")).clear();
			    driver.findElement(By.id("password")).sendKeys(password[indexTimes]);
			    driver.findElement(By.id("btn-login")).click();
			    
		    }
		    
		    driver.getCurrentUrl();

		    driver.findElement(By.xpath("//*[@id='login-box']/div[3]/div[2]/input")).clear();
		    driver.findElement(By.xpath("//*[@id='login-box']/div[3]/div[2]/input")).sendKeys(username[5]);
		    driver.findElement(By.xpath("//*[@id='login-box']/div[3]/div[5]/input")).sendKeys("password[5]");
		    driver.findElement(By.xpath("//*[@id='login-box']/div[3]/div[7]/input")).click();
		    
		  
		    if (driver.findElement(By.xpath("//*[@id='login-box']/div[3]/div[7]")).isDisplayed())
		    {
		    	System.out.println("Captch Is Displayed. Test Case Passed");
		    }
		    else
		    {
		    	System.out.println("Captch is not displayed. Test Case Failed");
		    }
		    
		    WebElement captcha = driver.findElement(By.xpath("//*[@id='login-box']/div[3]/div[7]/div[1]/span/span"));
		   
		   String strCapValue =  captcha.getText();
		   strCapValue = strCapValue.replace("+", "");
		   

		   String[] arrayCapValue = strCapValue.split(" ");
		   
		   int n1,n2;
		   n1 = Integer.parseInt(arrayCapValue[0]);	   
		   n2 = Integer.parseInt(arrayCapValue[2]);
		   int capval = n1+n2;
		   System.out.println(capval);

		   
		  }

	  @Test
	  public void testTC0119() throws Exception {
			driver.navigate().to(baseUrl + "/");

		    String Forgot_Password = driver.findElement(By.xpath("//*[@id='password']")).getText(); 
		    
		    
			 try{
				 Class.forName("com.mysql.jdbc.Driver");
				 Connection con = DriverManager.getConnection("jdbc:mysql://localhost/cardplay","root","root");
				 Statement st = con.createStatement();
				 ResultSet  rs=  st.executeQuery("select * from cp_user where activation_code =' "+Forgot_Password+"'");	
				 
				 
				 int f = 0;
				 while (rs.next())
				 {
					 f = 1;
				 }
				// if(f == 1 && )
				 
			 }
			 catch(Exception E){
				 System.out.println(E.toString());
			 }
	  }

	  

	  @Test
	  public void testUntitled2() throws Exception {
		driver.navigate().to(baseUrl + "/");
	   
	    driver.findElement(By.id("btnSignUp")).click();

	  
	   // To check Auto focus
	    if( driver.findElement(By.id("reg_username")).isSelected())
	    {
	    	driver.findElement(By.id("reg_username")).sendKeys("abc");
	    	
	    }
	    
	   else
	   {
		   System.out.println("Test Case Is Failed");
	   }
	   
	   // To check Water mark text disappears on click
	   driver.findElement(By.id("btnSignUp")).click();
	   driver.findElement(By.id("reg_username")).click();
	   
	   if(driver.findElement(By.id("reg_username")).getText().isEmpty())
			   {
		   System.out.println("Test Case Passed");
			   }
	   else 
	   {
		   System.out.println("Test Case Failed");
		   
	   }
	   
	   
	   /* 
	    if( driver.findElement(By.id("reg_password")).isEnabled())
	    {
	    	driver.findElement(By.id("reg_password")).sendKeys("abc");
	    	
	    }
	    */
	    System.out.println("End ");
	  }
	  

	  
	  public void testPassword() throws Exception {
			driver.navigate().to(baseUrl + "/");  
		    driver.findElement(By.xpath("html/body/div[3]/div/div/img")).click();
		    driver.findElement(By.id("reg_username")).click();
		    driver.findElement(By.id("reg_username")).clear();
		    driver.findElement(By.id("reg_username")).sendKeys("testbtestbaaabb");
		    driver.findElement(By.id("password_clear")).clear();
		    driver.findElement(By.id("password_clear")).sendKeys("Password");
		    driver.findElement(By.id("reg_password")).clear();
		    driver.findElement(By.id("reg_password")).sendKeys("testbtestaaaa");
		    driver.findElement(By.id("email")).clear();
		    driver.findElement(By.id("email")).sendKeys("testbaaabbbb@gauss.com");
		    new Select(driver.findElement(By.id("dobyear"))).selectByVisibleText("1996");
		    driver.findElement(By.cssSelector("option[value=\"1996\"]")).click();
		    new Select(driver.findElement(By.id("gender"))).selectByVisibleText("Male");
		    driver.findElement(By.id("agree")).click();
		    driver.findElement(By.id("btn-signup")).click();
	  }

	  @After
	  public void tearDown() throws Exception {
		  /*
	        // take the screen shot at the end of every test
	        File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	        // now save the screen shot to a file some place
	        FileUtils.copyFile(scrFile, new File("c:\\test\\screenshot.png"));
		    */
		    driver.quit();
		    String verificationErrorString = verificationErrors.toString();
		    if (!"".equals(verificationErrorString)) {
		      fail(verificationErrorString);
		    }
	        driver.quit();

	  }

	  private boolean isElementPresent(By by) {
	    try {
	      driver.findElement(by);
	      return true;
	    } catch (NoSuchElementException e) {
	      return false;
	    }
	  }

	  private boolean isAlertPresent() {
	    try {
	      driver.switchTo().alert();
	      return true;
	    } catch (NoAlertPresentException e) {
	      return false;
	    }
	  }

	private String closeAlertAndGetItsText() {
	    try {
	      Alert alert = driver.switchTo().alert();
	      String alertText = alert.getText();
	      if (acceptNextAlert) {
	        alert.accept();
	      } else {
	        alert.dismiss();
	      }
	      return alertText;
	    } finally {
	      acceptNextAlert = true;
	    }
	  }
	
}
	

