//=======================================================================================
// --- Created By: Rahul Shrivastava
// --- Created Date: 16-06-2014
// --- Modified Date: 
// --- Modified By: 
//=======================================================================================

package testcases;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.LocalFileDetector;

import utilities.BrowserStartup;
import utilities.Common;
import databaseconnection.DbConnection;

public class MyAccount extends BrowserStartup {

	private static WebDriver driver;
	private static String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();
	private Map<String, String> innerResultMap = null;
	private Common common = new Common();

	private String user_name = "mohit";

	@BeforeClass
	public static void setUp() throws Exception {

		driver = new FirefoxDriver();
		baseUrl = "http://adda52.com/";

		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.get(baseUrl + "/");
		driver.findElement(By.id("username")).click();
		driver.findElement(By.id("username")).clear();
		driver.findElement(By.id("username")).sendKeys(Common.test_user);
		driver.findElement(By.id("password")).clear();
		driver.findElement(By.id("password")).sendKeys(Common.test_password);
		driver.findElement(By.id("btn-login")).click();

	}

	@Test
	public void testTC0161() throws Exception {
		driver.navigate().to(baseUrl + "/");
		// driver.get(baseUrl + "/");
		// driver.findElement(By.id("username")).click();
		// driver.findElement(By.id("username")).clear();
		// driver.findElement(By.id("username")).sendKeys(Common.uname);
		// driver.findElement(By.id("password")).clear();
		// driver.findElement(By.id("password")).sendKeys(Common.password);
		// driver.findElement(By.id("btn-login")).click();
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.cssSelector("a > span")).click();
		driver.get(baseUrl + "/my-account");
	}

	@Test
	public void testTC0162() throws Exception {
		// driver.get(baseUrl + "/");
		// driver.findElement(By.linkText("Adda52.com")).click();
		// driver.findElement(By.id("username")).clear();
		// driver.findElement(By.id("username")).sendKeys(Common.uname);
		// driver.findElement(By.id("password")).click();
		// driver.findElement(By.id("password")).clear();
		// driver.findElement(By.id("password")).sendKeys(Common.password);
		// driver.findElement(By.id("btn-login")).click();
		driver.navigate().to(baseUrl + "/");
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.cssSelector("a > span")).click();
		try {
			assertTrue(isElementPresent(By
					.xpath("//form[@id='profileInfo']/div/div[2]/label")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertTrue(isElementPresent(By
					.xpath("//form[@id='profileInfo']/div/div[3]/label")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertTrue(isElementPresent(By
					.xpath("//form[@id='profileInfo']/div/div[4]/label")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertTrue(isElementPresent(By
					.xpath("//form[@id='profileInfo']/div/div[5]/label")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertTrue(isElementPresent(By
					.xpath("//form[@id='profileInfo']/div/div[6]/label")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertTrue(isElementPresent(By
					.xpath("//form[@id='profileInfo']/div/div[7]/label")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertTrue(isElementPresent(By
					.xpath("//form[@id='profileInfo']/div/div[8]/label")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertTrue(isElementPresent(By
					.xpath("//form[@id='profileInfo']/div/div[9]/label")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertTrue(isElementPresent(By
					.xpath("//form[@id='profileInfo']/div/div[10]/label")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertTrue(isElementPresent(By
					.xpath("//form[@id='profileInfo']/div/div[11]/label")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertTrue(isElementPresent(By
					.xpath("//form[@id='profileInfo']/div/div[12]/label")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertTrue(isElementPresent(By
					.xpath("//form[@id='profileInfo']/div/div[13]/label")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
	}

	@Test
	public void testTC0163() throws Exception {
		driver.navigate().to(baseUrl + "/");
		// driver.get(baseUrl + "/");
		// driver.findElement(By.id("username")).click();
		// driver.findElement(By.id("username")).click();
		// driver.findElement(By.id("username")).clear();
		// driver.findElement(By.id("username")).sendKeys(Common.uname);
		// driver.findElement(By.id("password")).clear();
		// driver.findElement(By.id("password")).sendKeys(Common.password);
		// driver.findElement(By.id("btn-login")).click();
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.cssSelector("a > span")).click();
		driver.findElement(By.xpath("//*[@id='profileInfo']/div/div[5]"));

		// To verify Email field is disabled
		if (driver.findElement(By.xpath("//*[@id='profileInfo']/div/div[5]"))
				.isSelected()) {
			driver.findElement(By.xpath("//*[@id='profileInfo']/div/div[5]"))
					.sendKeys("ABC");
			System.out.println("Email Is Enabled and Editable");
		} else {
			System.out.println("Email is Disabled");
		}

		// To verify Gender field is disabled
		if (driver.findElement(By.xpath("//*[@id='profileInfo']/div/div[6]"))
				.isSelected()) {
			driver.findElement(By.xpath("//*[@id='profileInfo']/div/div[6]"))
					.sendKeys("ABC");
			System.out.println("Gender Is Enabled and Editable");
		} else {
			System.out.println("Gender is Disabled");
		}

		// To verify Birth Year field is disabled
		if (driver.findElement(By.xpath("//*[@id='profileInfo']/div/div[7]"))
				.isSelected()) {
			driver.findElement(By.xpath("//*[@id='profileInfo']/div/div[7]"))
					.sendKeys("ABC");
			System.out.println("Birht Year Is Enabled and Editable");
		} else {
			System.out.println("Birth Year is Disabled");
		}

	}

	@Test
	// public void testTC0164_TC0168() throws Exception {
	public void testTC0164() throws Exception {
		innerResultMap = new HashMap<String, String>();
		driver.navigate().to(baseUrl + "/");
		// driver.get(baseUrl + "/");
		// driver.findElement(By.id("username")).clear();
		// driver.findElement(By.id("username")).sendKeys(Common.uname);
		// driver.findElement(By.id("password")).clear();
		// driver.findElement(By.id("password")).sendKeys(Common.password);
		// driver.findElement(By.id("btn-login")).click();
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.cssSelector("a > span")).click();
		// driver.findElement(By.id("firstname")).clear();
		driver.findElement(By.id("firstname")).sendKeys("rahulshri@");
		driver.findElement(By.id("btn-save")).click();
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// name=fbMainContainer | ]]
		// driver.findElement(By.id("fbInspectButton")).click();
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// null | ]]
		try {
			assertEquals(
					"The First Name field may only contain alphabetical characters.",
					driver.findElement(By.id("my_fname")).getText());
			if (driver
					.findElement(By.id("my_fname"))
					.getText()
					.equals("The First Name field may only contain alphabetical characters.")) {

				innerResultMap.put("TC0164", "PASS");

			} else {
				innerResultMap.put("TC0164", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("firstname")).sendKeys("rahulshri#");
		driver.findElement(By.id("btn-save")).click();
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// name=fbMainContainer | ]]
		// driver.findElement(By.id("fbInspectButton")).click();
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// null | ]]
		try {
			assertEquals(
					"The First Name field may only contain alphabetical characters.",
					driver.findElement(By.id("my_fname")).getText());
			if (driver
					.findElement(By.id("my_fname"))
					.getText()
					.equals("The First Name field may only contain alphabetical characters.")) {

				innerResultMap.put("TC0165", "PASS");

			} else {
				innerResultMap.put("TC0165", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("firstname")).clear();
		driver.findElement(By.id("firstname")).sendKeys("rahulshri*");
		driver.findElement(By.id("btn-save")).click();
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// name=fbMainContainer | ]]
		// driver.findElement(By.id("fbInspectButton")).click();
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// null | ]]
		try {
			assertEquals(
					"The First Name field may only contain alphabetical characters.",
					driver.findElement(By.id("my_fname")).getText());
			if (driver
					.findElement(By.id("my_fname"))
					.getText()
					.equals("The First Name field may only contain alphabetical characters.")) {

				innerResultMap.put("TC0166", "PASS");

			} else {
				innerResultMap.put("TC0166", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("firstname")).clear();
		driver.findElement(By.id("firstname"))
				.sendKeys("qawsedrftgyhujikolpqa");
		driver.findElement(By.id("btn-save")).click();
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// name=fbMainContainer | ]]
		// driver.findElement(By.id("fbInspectButton")).click();
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// null | ]]
		try {
			assertEquals(
					"The First Name field can not exceed 20 characters in length.",
					driver.findElement(By.id("my_fname")).getText());
			if (driver
					.findElement(By.id("my_fname"))
					.getText()
					.equals("The First Name field may only contain alphabetical characters.")) {

				innerResultMap.put("TC0167", "PASS");

			} else {
				innerResultMap.put("TC0167", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		common.getInnerResultMap().putAll(innerResultMap);
	}

	// TC0170 - TC0174
	@Test
	public void testTC0170TC0174() throws Exception {
		innerResultMap = new HashMap<String, String>();
		// driver.get(baseUrl + "/");
		driver.navigate().to(baseUrl + "/");
		// //
		// assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
		// driver.getTitle());
		// driver.findElement(By.linkText("Adda52.com")).click();
		// //
		// assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
		// driver.getTitle());
		// driver.findElement(By.id("username")).clear();
		// driver.findElement(By.id("username")).sendKeys("rahulsh");
		// driver.findElement(By.id("password")).clear();
		// driver.findElement(By.id("password")).sendKeys("gauss123");
		// driver.findElement(By.id("btn-login")).click();
		// assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
		// driver.getTitle());
		driver.findElement(By.linkText("My Account")).click();
		// assertEquals("Adda52.com", driver.getTitle());
		driver.findElement(
				By.xpath("//*[@id='wrapper']/section/div/aside[1]/ul/li[1]/a/span"))
				.click();
		// assertEquals("Adda52.com", driver.getTitle());
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// name=fbMainContainer | ]]
		// driver.findElement(By.id("fbInspectButton")).click();
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// null | ]]
		driver.findElement(By.xpath("//*[@id='lastname']")).click();
		try {
			assertTrue(isElementPresent(By.xpath("//*[@id='lastname']")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("lastname")).clear();
		driver.findElement(By.id("lastname")).sendKeys("@#!$@#%$#@%@#");
		driver.findElement(By.id("btn-save")).click();
		// assertEquals("Adda52.com", driver.getTitle());
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// name=fbMainContainer | ]]
		// driver.findElement(By.id("fbInspectButton")).click();
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// null | ]]
		try {
			assertEquals(
					"The Last Name field may only contain alphabetical characters.",
					driver.findElement(By.id("my_lname")).getText());
			if (driver
					.findElement(By.id("my_lname"))
					.getText()
					.equals("The Last Name field may only contain alphabetical characters.")) {

				innerResultMap.put("TC0170", "PASS");

			} else {
				innerResultMap.put("TC0170", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("lastname")).clear();
		driver.findElement(By.id("lastname")).sendKeys("@$@#$@#$test");
		driver.findElement(By.id("btn-save")).click();
		assertEquals("Adda52.com", driver.getTitle());
		try {
			assertEquals(
					"The Last Name field may only contain alphabetical characters.",
					driver.findElement(By.id("my_lname")).getText());
			if (driver
					.findElement(By.id("my_lname"))
					.getText()
					.equals("The Last Name field may only contain alphabetical characters.")) {

				innerResultMap.put("TC0171", "PASS");

			} else {
				innerResultMap.put("TC0171", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("lastname")).clear();
		driver.findElement(By.id("lastname")).sendKeys("test@#$@#$@#$");
		driver.findElement(By.id("btn-save")).click();
		assertEquals("Adda52.com", driver.getTitle());
		try {
			assertTrue(isElementPresent(By.id("my_lname")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("lastname")).clear();
		driver.findElement(By.id("lastname")).sendKeys("!@#!@#!@#12345");
		driver.findElement(By.id("btn-save")).click();
		assertEquals("Adda52.com", driver.getTitle());
		try {
			assertEquals(
					"The Last Name field may only contain alphabetical characters.",
					driver.findElement(By.id("my_lname")).getText());
			if (driver
					.findElement(By.id("my_lname"))
					.getText()
					.equals("The Last Name field may only contain alphabetical characters.")) {

				innerResultMap.put("TC0172", "PASS");

			} else {
				innerResultMap.put("TC0172", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("lastname")).clear();
		driver.findElement(By.id("lastname")).sendKeys("12345!@#$@!$@#$");
		driver.findElement(By.id("btn-save")).click();
		assertEquals("Adda52.com", driver.getTitle());
		try {
			assertTrue(isElementPresent(By.id("my_lname")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("lastname")).clear();
		driver.findElement(By.id("lastname")).sendKeys("test23432423");
		driver.findElement(By.id("btn-save")).click();
		assertEquals("Adda52.com", driver.getTitle());
		try {
			assertEquals(
					"The Last Name field may only contain alphabetical characters.",
					driver.findElement(By.id("my_lname")).getText());
			if (driver
					.findElement(By.id("my_lname"))
					.getText()
					.equals("The Last Name field may only contain alphabetical characters.")) {

				innerResultMap.put("TC0173", "PASS");

			} else {
				innerResultMap.put("TC0173", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("lastname")).clear();
		driver.findElement(By.id("lastname")).sendKeys("65324234testing");
		driver.findElement(By.id("btn-save")).click();
		assertEquals("Adda52.com", driver.getTitle());
		try {
			assertTrue(isElementPresent(By.id("my_lname")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("lastname")).clear();
		driver.findElement(By.id("lastname")).sendKeys("qawsedrftgyhujikolpqa");
		driver.findElement(By.id("btn-save")).click();
		assertEquals("Adda52.com", driver.getTitle());
		try {
			assertEquals(
					"The Last Name field can not exceed 20 characters in length.",
					driver.findElement(By.id("my_lname")).getText());
			if (driver
					.findElement(By.id("my_lname"))
					.getText()
					.equals("The Last Name field can not exceed 20 characters in length.")) {

				innerResultMap.put("TC0174", "PASS");

			} else {
				innerResultMap.put("TC0174", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		common.getInnerResultMap().putAll(innerResultMap);
	}

	@Test
	public void testUntitled() throws Exception {
		// driver.get(baseUrl + "/");
		driver.navigate().to(baseUrl + "/");
		// driver.findElement(By.id("username")).click();
		// driver.findElement(By.id("username")).clear();
		// driver.findElement(By.id("username")).sendKeys(Common.uname);
		// driver.findElement(By.id("password")).clear();
		// driver.findElement(By.id("password")).sendKeys(Common.password);
		// driver.findElement(By.id("btn-login")).click();
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.cssSelector("a > span")).click();
		driver.findElement(By.id("lastname")).clear();
		driver.findElement(By.id("lastname")).sendKeys("test#");
		driver.findElement(By.id("btn-save")).click();
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// name=fbMainContainer | ]]
		// driver.findElement(By.id("fbInspectButton")).click();
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// null | ]]
		try {
			assertEquals(
					"The Last Name field may only contain alphabetical characters.",
					driver.findElement(By.id("my_lname")).getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("lastname")).clear();
		driver.findElement(By.id("lastname")).sendKeys("test@");
		driver.findElement(By.id("btn-save")).click();
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// name=fbMainContainer | ]]
		// driver.findElement(By.id("fbInspectButton")).click();
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// null | ]]
		try {
			assertEquals(
					"The Last Name field may only contain alphabetical characters.",
					driver.findElement(By.id("my_lname")).getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("lastname")).clear();
		driver.findElement(By.id("lastname")).sendKeys("test*");
		driver.findElement(By.id("btn-save")).click();
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// name=fbMainContainer | ]]
		// driver.findElement(By.id("fbInspectButton")).click();
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// null | ]]
		try {
			assertEquals(
					"The Last Name field may only contain alphabetical characters.",
					driver.findElement(By.id("my_lname")).getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("lastname")).clear();
		driver.findElement(By.id("lastname")).sendKeys("test12");
		driver.findElement(By.id("btn-save")).click();
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// name=fbMainContainer | ]]
		// driver.findElement(By.id("fbInspectButton")).click();
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// null | ]]
		try {
			assertEquals(
					"The Last Name field may only contain alphabetical characters.",
					driver.findElement(By.id("my_lname")).getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
	}

	@Test
	// public void testTC0176_TC0183() throws Exception {
	public void testTC0176() throws Exception {
		innerResultMap = new HashMap<String, String>();
		// driver.get(baseUrl + "/");
		driver.navigate().to(baseUrl + "/");
		// driver.findElement(By.id("username")).click();
		// driver.findElement(By.id("username")).clear();
		// driver.findElement(By.id("username")).sendKeys(Common.uname);
		// driver.findElement(By.id("password")).clear();
		// driver.findElement(By.id("password")).sendKeys(Common.password);
		// driver.findElement(By.id("btn-login")).click();
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.cssSelector("a > span")).click();
		try {
			Thread.sleep(2000);
			assertTrue(isElementPresent(By.id("testclick1")));
			if (driver.findElement(By.id("testclick1")).isDisplayed()) {

				innerResultMap.put("TC0176", "PASS");

			} else {
				innerResultMap.put("TC0176", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.cssSelector("strong")).click();

		String myWindowHandle = driver.getWindowHandle();
		driver.switchTo().window(myWindowHandle);

		driver.findElement(By.xpath("//*[@id='tinycontent']/div[2]"));
		driver.findElement(By.xpath("//*[@id='tinycontent']/div[1]/div[1]"));
		driver.findElement(By.xpath("//*[@id='tinycontent']/div[1]/div[2]/a"));
		driver.findElement(By.xpath("//*[@id='mobile']/div[2]/label"));
		driver.findElement(By.xpath("//*[@id='mobile']"));
		driver.findElement(By.xpath("//*[@id='btn-save']"));
		driver.findElement(By.xpath("//*[@id='mobile']"))
				.sendKeys("7840049118");
		driver.findElement(By.xpath("(//input[@id='btn-save'])[2]")).click();
		try {
			assertEquals("Invalid mobile number.",
					driver.findElement(By.id("mobile_err")).getText());
			if (driver.findElement(By.id("mobile_err")).getText()
					.equals("Invalid mobile number.")) {

				innerResultMap.put("TC0177", "PASS");

			} else {
				innerResultMap.put("TC0177", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		common.getInnerResultMap().putAll(innerResultMap);
	}

	@Test
	public void testPopUp() throws Exception {
		// driver.get(baseUrl + "/");
		driver.navigate().to(baseUrl + "/");
		// driver.findElement(By.id("username")).click();
		// driver.findElement(By.id("username")).clear();
		// driver.findElement(By.id("username")).sendKeys(Common.uname);
		// driver.findElement(By.id("password")).clear();
		// driver.findElement(By.id("password")).sendKeys(Common.password);
		// driver.findElement(By.id("btn-login")).click();
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.cssSelector("a > span")).click();
		try {
			Thread.sleep(2000);
			assertTrue(isElementPresent(By.id("testclick1")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.cssSelector("strong")).click();
		String myWindowHandle = driver.getWindowHandle();
		driver.switchTo().window(myWindowHandle);
		driver.findElement(By.xpath("//*[@id='tinycontent']/div[2]"));
		driver.findElement(By.xpath("//*[@id='tinycontent']/div[1]/div[1]"));
		driver.findElement(By.xpath("//*[@id='tinycontent']/div[1]/div[2]/a"));
		driver.findElement(By.xpath("//*[@id='mobile']/div[2]/label"));
		driver.findElement(By.xpath("//*[@id='mobile']"));
		driver.findElement(By.xpath("//*[@id='btn-save']"));
		WebElement PopUp = driver.findElement(By.xpath("//*[@id='mobile']"));
		PopUp.sendKeys("7897897897");

	}

	@Test
	public void testTC0184() throws Exception {
		// driver.get(baseUrl + "/");
		driver.navigate().to(baseUrl + "/");
		// driver.findElement(By.id("username")).clear();
		// driver.findElement(By.id("username")).sendKeys(Common.uname);
		// driver.findElement(By.id("password")).clear();
		// driver.findElement(By.id("password")).sendKeys(Common.password);
		// driver.findElement(By.id("btn-login")).click();
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.cssSelector("a > span")).click();
		driver.findElement(By.cssSelector("strong")).click();
		// ERROR: Caught exception [Error: Dom locators are not implemented
		// yet!]
		driver.findElement(By.xpath("(//input[@id='btn-save'])[2]")).click();
		try {
			assertEquals("Mobile already exists, please use a different one.",
					driver.findElement(By.id("mobile_err")).getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
	}

	@Test
	public void testTC0186() throws Exception {
		// driver.get(baseUrl + "/");
		driver.navigate().to(baseUrl + "/");
		// driver.findElement(By.id("username")).clear();
		// driver.findElement(By.id("username")).sendKeys(Common.uname);
		// driver.findElement(By.id("password")).clear();
		// driver.findElement(By.id("password")).sendKeys(Common.password);
		// driver.findElement(By.id("btn-login")).click();
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.cssSelector("a > span")).click();
		driver.findElement(By.cssSelector("strong")).click();
		// ERROR: Caught exception [Error: Dom locators are not implemented
		// yet!]
		driver.findElement(By.xpath("(//input[@id='btn-save'])[2]")).click();
		try {
			assertTrue(isElementPresent(By.id("tinybox")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
	}

	@Test
	public void testTC0192() throws Exception {

		// driver.get(baseUrl + "/");
		driver.navigate().to(baseUrl + "/");
		// driver.findElement(By.xpath("html/body/div[1]/div/div/img")).click();
		// driver.findElement(By.id("username")).clear();
		// driver.findElement(By.id("username")).sendKeys(Common.uname);
		// driver.findElement(By.id("password")).clear();
		// driver.findElement(By.id("password")).sendKeys(Common.password);
		// driver.findElement(By.id("btn-login")).click();
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.cssSelector("a > span")).click();

		driver.findElement(
				By.xpath("//*[@id='profileInfo']/div/div[1]/span/input"))
				.click();

		WebElement w = driver.findElement(By
				.xpath("//*[@id='profileInfo']/div/div[1]/label/img"));

		if (w.getAttribute("src") != "http://www.adda52.com/images/default/profile-pic.png") {

		}
		String s = driver.getTitle();

		LocalFileDetector detector = new LocalFileDetector();

		if (detector != null) {
			System.out
					.println("Window to select image gets opened fine. Test Case Passed.");
		} else {
			System.out
					.println("Window to select image is not opened. Test Case Fail.");
		}

	}

	// TC0211 - TC0221
	@Test
	public void testTC0211TC0221() throws Exception {
		innerResultMap = new HashMap<String, String>();
		// driver.get(baseUrl + "/");
		driver.navigate().to(baseUrl + "/");
		// //
		// assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
		// driver.getTitle());
		// driver.findElement(By.linkText("Adda52.com")).click();
		// //
		// assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
		// driver.getTitle());
		// driver.findElement(By.id("username")).clear();
		// driver.findElement(By.id("username")).sendKeys("rahulsh");
		// driver.findElement(By.id("password")).clear();
		// driver.findElement(By.id("password")).sendKeys("gauss123");
		// driver.findElement(By.id("btn-login")).click();
		assertEquals(
				"Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
				driver.getTitle());
		driver.findElement(By.linkText("My Account")).click();
		assertEquals("Adda52.com", driver.getTitle());
		driver.findElement(
				By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[2]/a/span"))
				.click();
		// assertEquals("Adda52.com", driver.getTitle());
		try {
			assertTrue(isElementPresent(By.name("currPasswd")));
			if (driver.findElement(
					By.xpath("//*[@id='changePwd']/div[1]/input"))
					.isDisplayed()
					&& driver.findElement(
							By.xpath("//*[@id='changePwd']/div[2]/input"))
							.isDisplayed()
					&& driver.findElement(
							By.xpath("//*[@id='changePwd']/div[3]/input"))
							.isDisplayed()
					&& driver.findElement(By.xpath("//*[@id='btn-update']"))
							.isDisplayed()) {
				innerResultMap.put("TC0211", "PASS");
			} else {
				innerResultMap.put("TC0211", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}

		try {
			driver.findElement(By.id("btn-update")).click();
			assertEquals("The Current Password field is required.", driver
					.findElement(By.id("currPasswd_err")).getText());
			assertEquals("The New Password field is required.", driver
					.findElement(By.id("newPasswd_err")).getText());

			if (driver.findElement(By.id("currPasswd_err")).getText()
					.equals("The Current Password field is required.")
					&& driver.findElement(By.id("newPasswd_err")).getText()
							.equals("The New Password field is required.")) {

				innerResultMap.put("TC0212", "PASS");

			} else {
				innerResultMap.put("TC0212", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}

		try {
			driver.findElement(By.xpath("//*[@id='changePwd']/div[2]/input"))
					.sendKeys("testingcurrent");
			driver.findElement(By.xpath("//*[@id='changePwd']/div[3]/input"))
					.sendKeys("testingcurrent");
			driver.findElement(By.xpath("//*[@id='btn-update']")).click();

			assertEquals("The Current Password field is required.", driver
					.findElement(By.id("currPasswd_err")).getText());

			if (driver.findElement(By.id("currPasswd_err")).getText()
					.equals("The Current Password field is required.")) {

				innerResultMap.put("TC0213", "PASS");

			} else {
				innerResultMap.put("TC0213", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}

		try {
			driver.findElement(By.xpath("//*[@id='changePwd']/div[1]/input"))
					.sendKeys("gauss123");
			driver.findElement(By.xpath("//*[@id='changePwd']/div[3]/input"))
					.sendKeys("testingcurrent");
			driver.findElement(By.xpath("//*[@id='btn-update']")).click();

			assertEquals("The New Password field is required.", driver
					.findElement(By.xpath("//*[@id='newPasswd_err']"))
					.getText());

			if (driver.findElement(By.xpath("//*[@id='newPasswd_err']"))
					.getText().equals("The New Password field is required.")) {

				innerResultMap.put("TC0215", "PASS");

			} else {
				innerResultMap.put("TC0215", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}

		try {
			driver.findElement(By.xpath("//*[@id='changePwd']/div[1]/input"))
					.sendKeys("gauss123");
			driver.findElement(By.xpath("//*[@id='changePwd']/div[2]/input"))
					.sendKeys("testing");
			driver.findElement(By.xpath("//*[@id='changePwd']/div[3]/input"))
					.sendKeys("testing");
			driver.findElement(By.xpath("//*[@id='btn-update']")).click();

			assertEquals(
					"The New Password field must be minimum 8 and maximum 20 characters in length.",
					driver.findElement(By.xpath("//*[@id='newPasswd_err']"))
							.getText());

			if (driver
					.findElement(By.xpath("//*[@id='newPasswd_err']"))
					.getText()
					.equals("The New Password field must be minimum 8 and maximum 20 characters in length.")) {

				innerResultMap.put("TC0216", "PASS");

			} else {
				innerResultMap.put("TC0216", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}

		try {
			driver.findElement(By.xpath("//*[@id='changePwd']/div[1]/input"))
					.sendKeys("gauss123");
			driver.findElement(By.xpath("//*[@id='changePwd']/div[2]/input"))
					.sendKeys("aqswdefrtgyhujikolpaq");
			driver.findElement(By.xpath("//*[@id='changePwd']/div[3]/input"))
					.sendKeys("aqswdefrtgyhujikolpaq");
			driver.findElement(By.xpath("//*[@id='btn-update']")).click();

			assertEquals(
					"The New Password field must be minimum 8 and maximum 20 characters in length.",
					driver.findElement(By.xpath("//*[@id='newPasswd_err']"))
							.getText());

			if (driver
					.findElement(By.xpath("//*[@id='newPasswd_err']"))
					.getText()
					.equals("The New Password field must be minimum 8 and maximum 20 characters in length.")) {

				innerResultMap.put("TC0217", "PASS");

			} else {
				innerResultMap.put("TC0217", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			driver.findElement(By.xpath("//*[@id='changePwd']/div[1]/input"))
					.sendKeys("gauss123");
			driver.findElement(By.xpath("//*[@id='changePwd']/div[2]/input"))
					.sendKeys("testinggauss");
			driver.findElement(By.xpath("//*[@id='changePwd']/div[3]/input"))
					.sendKeys("testinggauss1234");
			driver.findElement(By.xpath("//*[@id='btn-update']")).click();

			assertEquals("New and Confirm Passwords do not match.", driver
					.findElement(By.xpath("//*[@id='confirmPasswd_err']"))
					.getText());

			if (driver.findElement(
					By.xpath("//*[@id='changePwd']/div[2]/input")).getText() == driver
					.findElement(By.xpath("//*[@id='changePwd']/div[3]/input"))
					.getText()) {

				innerResultMap.put("TC0220", "PASS");

			} else {
				innerResultMap.put("TC0220", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		common.getInnerResultMap().putAll(innerResultMap);

	}

	/*
	 * @Test public void testTC0211() throws Exception { driver.get(baseUrl +
	 * "/");
	 * driver.findElement(By.xpath("html/body/div[1]/div/div/img")).click();
	 * 
	 * driver.findElement(By.id("username")).clear();
	 * driver.findElement(By.id("username")).sendKeys(Common.uname);
	 * driver.findElement(By.id("password")).clear();
	 * driver.findElement(By.id("password")).sendKeys(Common.password);
	 * driver.findElement(By.id("btn-login")).click();
	 * driver.findElement(By.linkText("My Account")).click();
	 * driver.findElement(
	 * By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[2]/a/span"
	 * )).click(); driver.get(baseUrl + "/my-account/change-password");
	 * 
	 * driver.findElement(By.xpath("//*[@id='wrapper']/section/div/article/div"))
	 * ; try { assertTrue(isElementPresent(By.xpath(
	 * "//*[@id='wrapper']/section/div/article/div"))); } catch (Error e) {
	 * verificationErrors.append(e.toString()); }
	 * driver.findElement(By.xpath("//*[@id='wrapper']/section/div/article/div/h2"
	 * )); try { assertTrue(isElementPresent(By.xpath(
	 * "//*[@id='wrapper']/section/div/article/div/h2"))); } catch (Error e) {
	 * verificationErrors.append(e.toString()); }
	 * 
	 * driver.findElement(By.xpath("//*[@id='changePwd']/div[1]/label")); try {
	 * assertTrue
	 * (isElementPresent(By.xpath("//*[@id='changePwd']/div[1]/label"))); }
	 * catch (Error e) { verificationErrors.append(e.toString()); }
	 * 
	 * driver.findElement(By.xpath("//*[@id='changePwd']/div[2]/label")); try {
	 * assertTrue
	 * (isElementPresent(By.xpath("//*[@id='changePwd']/div[2]/label"))); }
	 * catch (Error e) { verificationErrors.append(e.toString()); }
	 * 
	 * driver.findElement(By.xpath("//*[@id='changePwd']/div[3]/label")); try {
	 * assertTrue
	 * (isElementPresent(By.xpath("//*[@id='changePwd']/div[3]/label"))); }
	 * catch (Error e) { verificationErrors.append(e.toString()); }
	 * 
	 * driver.findElement(By.xpath("//*[@id='changePwd']/div[1]/input")); try {
	 * assertTrue
	 * (isElementPresent(By.xpath("//*[@id='changePwd']/div[1]/input"))); }
	 * catch (Error e) { verificationErrors.append(e.toString()); }
	 * 
	 * driver.findElement(By.xpath("//*[@id='changePwd']/div[2]/input")); try {
	 * assertTrue
	 * (isElementPresent(By.xpath("//*[@id='changePwd']/div[2]/input"))); }
	 * catch (Error e) { verificationErrors.append(e.toString()); }
	 * 
	 * driver.findElement(By.xpath("//*[@id='changePwd']/div[3]/input")); try {
	 * assertTrue
	 * (isElementPresent(By.xpath("//*[@id='changePwd']/div[3]/input"))); }
	 * catch (Error e) { verificationErrors.append(e.toString()); }
	 * 
	 * driver.findElement(By.xpath("//*[@id='btn-update']")); try {
	 * assertTrue(isElementPresent(By.id("btn-update"))); } catch (Error e) {
	 * verificationErrors.append(e.toString()); } }
	 * 
	 * @Test public void testTC0212() throws Exception {
	 * 
	 * driver.get(baseUrl + "/");
	 * driver.findElement(By.xpath("html/body/div[1]/div/div/img")).click();
	 * 
	 * driver.findElement(By.id("username")).clear();
	 * driver.findElement(By.id("username")).sendKeys(Common.uname);
	 * driver.findElement(By.id("password")).clear();
	 * driver.findElement(By.id("password")).sendKeys(Common.password);
	 * driver.findElement(By.id("btn-login")).click();
	 * driver.findElement(By.linkText("My Account")).click();
	 * driver.findElement(
	 * By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[2]/a/span"
	 * )).click(); driver.get(baseUrl + "/my-account/change-password");
	 * 
	 * driver.findElement(By.xpath("//*[@id='changePwd']/div[1]/input")).sendKeys
	 * ("");
	 * driver.findElement(By.xpath("//*[@id='changePwd']/div[2]/input")).sendKeys
	 * (""); driver.findElement(By.xpath("//*[@id='btn-update']")).click();
	 * 
	 * if(driver.findElement(By.xpath("//*[@id='currPasswd_err']")).getText().equals
	 * ("The Current Password field is required.") &&
	 * driver.findElement(By.xpath
	 * ("//*[@id='newPasswd_err']")).getText().equals(
	 * "The New Password field is required.")) {
	 * System.out.println("Test Case Has Passed"); } else{
	 * System.out.println("Test Case Has Failed"); } }
	 */

	// Buddy List
	@Test
	public void testTC0266() throws Exception {
		// driver.get(baseUrl + "/");
		driver.navigate().to(baseUrl + "/");
		//
		// driver.findElement(By.xpath("html/body/div[1]/div/div/img"));
		// driver.findElement(By.id("username")).clear();
		// driver.findElement(By.id("username")).sendKeys("rahulsh");
		// driver.findElement(By.id("password")).clear();
		// driver.findElement(By.id("password")).sendKeys("gauss123");
		// driver.findElement(By.id("btn-login")).click();
		driver.findElement(By.xpath("//*[@id='menu']/li[7]/a")).click();

		try {
			assertTrue(isElementPresent(By
					.cssSelector("span..firepath-matching-node")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.cssSelector("span..firepath-matching-node"))
				.click();
		try {
			assertTrue(isElementPresent(By
					.cssSelector("img..firepath-matching-node")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertTrue(isElementPresent(By
					.cssSelector("img..firepath-matching-node")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertTrue(isElementPresent(By
					.cssSelector("img..firepath-matching-node")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
	}

	// Buddy List
	@Test
	public void testTC0267() throws Exception {
		ArrayList<String> buddyList = new ArrayList<String>();
		ArrayList<String> UIBuddyList = new ArrayList<String>();
		// driver.get(baseUrl + "/");
		driver.navigate().to(baseUrl + "/");
		boolean buddyExist = false;
		// setUp();
		// driver.findElement(By.id("username")).clear();
		// driver.findElement(By.id("username")).sendKeys("rahulsh");
		// driver.findElement(By.id("password")).clear();
		// driver.findElement(By.id("password")).sendKeys("gauss123");
		// driver.findElement(By.id("btn-login")).click();
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(
				By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[8]/a/span"))
				.click();

		// String user_name =
		// driver.findElement(By.xpath("//*[@id='username']")).getText();

		try {

			boolean isBuddy = DbConnection.isBuddy(user_name);
			if (isBuddy == true) {
				String text = "";
				// Grab the table
				WebElement table = driver.findElement(
						By.className("my_account_scroll")).findElement(
						By.className("buddy_table"));

				// Now get all the TR elements from the table
				List<WebElement> allRows = table.findElements(By.tagName("tr"));
				// And iterate over them, getting the cells
				for (WebElement row : allRows) {
					List<WebElement> cells = row.findElements(By.tagName("td"));
					for (WebElement cell : cells) {
						text = cell.getText();
						if (text != null && !text.isEmpty()) {
							System.out.println(text);
							UIBuddyList.add(text); // / buddy list from UI has
													// been stored in array list
						}

					}
				}
				buddyList = DbConnection.getBuddyList(user_name);
				if (!buddyList.isEmpty()) {
					for (String buddy : buddyList) {
						buddyExist = false;
						for (String UIBuddy : UIBuddyList) {
							if (buddy.equals(UIBuddy)) {
								System.out.println("Buddy Exist");
								buddyExist = true;
								break;
							}
						}
						if (buddyExist == false) {
							break;
						}
					}
				}
				if (buddyExist == false) {
					System.out.println("Test Fails");
				}
			} else {
				String noBuddyMsg = driver
						.findElement(
								By.xpath("//*[@id='wrapper']/section/div/article/div[2]/div"))
						.getText();
				System.out.println(noBuddyMsg);
			}

		}

		catch (Exception E) {
			System.out.println(E.toString());
		}
	}

	@Test
	public void testTC0276() throws Exception {
		// driver.get(baseUrl + "/");
		driver.navigate().to(baseUrl + "/");
		// driver.findElement(By.id("username")).clear();
		// driver.findElement(By.id("username")).sendKeys("rahulsh");
		// driver.findElement(By.id("password")).clear();
		// driver.findElement(By.id("password")).sendKeys("gauss123");
		// driver.findElement(By.id("btn-login")).click();
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(
				By.xpath("//*[@id='wrapper']/section/div/aside[1]/ul/li[8]/a/span"))
				.click();
		driver.findElement(
				By.xpath("//*[@id='wrapper']/section/div/article/div[1]/a[2]/img"))
				.click();

		if (driver.getCurrentUrl().equals(
				"http://adda52.org/my-account/add-buddy")) {
			System.out.println("Test Case Passed.");
		} else {
			System.out.println("Test Case Failed.");
		}

	}

	@Test
	public void testTC0277() throws Exception {
		// driver.get(baseUrl + "/");
		driver.navigate().to(baseUrl + "/");
		// driver.findElement(By.id("username")).clear();
		// driver.findElement(By.id("username")).sendKeys("rahulsh");
		// driver.findElement(By.id("password")).clear();
		// driver.findElement(By.id("password")).sendKeys("gauss123");
		// driver.findElement(By.id("btn-login")).click();
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(
				By.xpath("//*[@id='wrapper']/section/div/aside[1]/ul/li[8]/a/span"))
				.click();
		driver.findElement(
				By.xpath("//*[@id='wrapper']/section/div/article/div[1]/a[2]/img"))
				.click();

		WebElement To = driver.findElement(By
				.xpath("//*[@id='addBuddy']/div[2]/input"));
		WebElement ToBox = driver.findElement(By
				.xpath("//*[@id='addBuddy']/div[2]/input"));

		WebElement Message = driver.findElement(By
				.xpath("//*[@id='addBuddy']/div[4]"));
		WebElement MessageBox = driver.findElement(By
				.xpath("//*[@id='addBuddy']/div[5]/textarea"));

		if (To.isDisplayed() && ToBox.isDisplayed() && Message.isDisplayed()
				&& MessageBox.isDisplayed()) {
			System.out.println("Test Case Passed");
		} else {
			System.out.println("Test Case Failed");
		}
	}

	@Test
	public void testTC278() throws Exception {
		// driver.get(baseUrl + "/");
		driver.navigate().to(baseUrl + "/");
		// driver.findElement(By.id("username")).click();
		// driver.findElement(By.id("username")).clear();
		// driver.findElement(By.id("username")).sendKeys("rahulsh");
		// driver.findElement(By.id("password")).clear();
		// driver.findElement(By.id("password")).sendKeys("gauss1");
		// driver.findElement(By.id("password")).click();
		// driver.findElement(By.id("password")).clear();
		// driver.findElement(By.id("password")).sendKeys("gauss123");
		// driver.findElement(By.id("btn-login")).click();
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(
				By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[8]/a/span"))
				.click();
		driver.findElement(
				By.xpath("//div[@id='wrapper']/section/div/article/div/a[2]/img"))
				.click();
		driver.findElement(By.id("btn-send")).click();

		if (driver.findElement(By.xpath("//*[@id='to_username_err']"))
				.getText().equals("The To field is required.")) {
			System.out.println("Test Case Passed");
		} else {
			System.out.println("Test Case Failed");
		}

	}

	@Test
	public void testTC0279() throws Exception {
		// driver.get(baseUrl + "/");
		driver.navigate().to(baseUrl + "/");
		// driver.findElement(By.id("username")).clear();
		// driver.findElement(By.id("username")).sendKeys("rahulsh");
		// driver.findElement(By.id("password")).clear();
		// driver.findElement(By.id("password")).sendKeys("gauss123");
		// driver.findElement(By.id("btn-login")).click();
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(
				By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[8]/a/span"))
				.click();
		driver.findElement(
				By.xpath("//div[@id='wrapper']/section/div/article/div/a[2]/img"))
				.click();
		driver.findElement(By.name("to_username")).clear();
		driver.findElement(By.name("to_username")).sendKeys(
				"asdghjgsdf@fsdasasd");
		driver.findElement(By.id("btn-send")).click();
		driver.findElement(By.id("to_username_err")).click();
		try {
			assertTrue(isElementPresent(By.id("to_username_err")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
	}

	@Test
	public void testTC0282() throws Exception {
		// driver.get(baseUrl + "/");
		driver.navigate().to(baseUrl + "/");
		// driver.findElement(By.id("username")).click();
		// driver.findElement(By.id("username")).clear();
		// driver.findElement(By.id("username")).sendKeys("rahulsh");
		// driver.findElement(By.id("password")).clear();
		// driver.findElement(By.id("password")).sendKeys("gauss123");
		// driver.findElement(By.id("btn-login")).click();
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(
				By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[8]/a/span"))
				.click();
		driver.findElement(
				By.xpath("//div[@id='wrapper']/section/div/article/div/a[2]/img"))
				.click();
		driver.findElement(By.name("to_username")).clear();
		driver.findElement(By.name("to_username")).sendKeys("samarth");
		driver.findElement(By.name("message")).clear();
		driver.findElement(By.name("message")).sendKeys(
				"testing buddy list success message");
		driver.findElement(By.id("btn-send")).click();
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// name=fbMainContainer | ]]
		driver.findElement(By.id("fbInspectButton")).click();
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// null | ]]
		driver.findElement(By.id("msg")).click();
		try {
			assertEquals("Your request has been sent successfully.", driver
					.findElement(By.id("msg")).getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
	}

	@Test
	public void testTC0283() throws Exception {
		// driver.get(baseUrl + "/");
		driver.navigate().to(baseUrl + "/");
		// driver.findElement(By.id("username")).clear();
		// driver.findElement(By.id("username")).sendKeys("rahulsh");
		// driver.findElement(By.id("password")).clear();
		// driver.findElement(By.id("password")).sendKeys("gauss123");
		// driver.findElement(By.id("btn-login")).click();
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(
				By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[8]/a/span"))
				.click();
		driver.findElement(
				By.xpath("//div[@id='wrapper']/section/div/article/div/a[2]/img"))
				.click();
		driver.findElement(By.name("to_username")).click();
		driver.findElement(By.name("to_username")).clear();
		driver.findElement(By.name("to_username")).sendKeys("rahulsh");
		driver.findElement(By.id("btn-send")).click();
		driver.findElement(By.id("to_username_err")).click();
		try {
			assertEquals("You can not send buddy request to self.", driver
					.findElement(By.id("to_username_err")).getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
	}

	// Purchase Summary - My Accounts
	@Test
	public void testTC0284() throws Exception {
		int purchase_count = 0;
		purchase_count = DbConnection.getPurchaseSummary(user_name);
		System.out.println("PURCHASE COUNT:" + purchase_count);
		if (driver.findElements(By.xpath("html/body/div[3]/div/div/img"))
				.size() != 0) {
			driver.findElement(By.xpath("html/body/div[3]/div/div/img"))
					.click();

		}
		driver.navigate().to(baseUrl + "/");
		// driver.findElement(By.xpath("//*[@id='username']")).click();
		// driver.findElement(By.xpath("//*[@id='password']")).clear();
		// driver.findElement(By.id("username")).sendKeys("rahulsh");
		// driver.findElement(By.id("password")).clear();
		// driver.findElement(By.id("password")).sendKeys("gauss123");
		// driver.findElement(By.id("btn-login")).click();
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(
				By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[3]/a/span"))
				.click();
		driver.findElement(By.linkText("Purchase Summary")).click();

		if (purchase_count == 0) {
			String text = driver
					.findElement(
							By.xpath("//*[@id='wrapper']/section/div/article/div[2]/div/table/tbody/tr[2]/td"))
					.getText();

			// to be openend for production run to see result
			// Assert.assertEquals(text, "No records found.");
			if (text.equals("No records found.")) {
				System.out.println(text);
				System.out.println("Test Case Pass");
			}
		} else if (purchase_count > 0) {

			// acc_summary_table
			WebElement table = driver.findElement(By
					.className("acc_summary_table"));

			// Now get all the TR elements from the table
			List<WebElement> allRows = table.findElements(By.tagName("tr"));

			int chips_count = allRows.size() - 1;

			if (chips_count == purchase_count) {

				// to be openend for production run to see result
				// Assert.assertEquals(purchase_count, chips_count);
				System.out.println("Chips Count from UI " + chips_count);
				System.out.println("TestCase Pass");
			}

		}

	}

	// Redeem Summary - My Accounts
	@Test
	public void testTC0285() throws Exception {
		int redeem_count = 0;
		redeem_count = DbConnection.getRedeemSummary(user_name);
		System.out.println("REDEEM COUNT:" + redeem_count);
		if (driver.findElements(By.xpath("html/body/div[3]/div/div/img"))
				.size() != 0) {
			driver.findElement(By.xpath("html/body/div[3]/div/div/img"))
					.click();

		}
		driver.navigate().to(baseUrl + "/");
		// driver.findElement(By.xpath("//*[@id='username']")).click();
		// driver.findElement(By.xpath("//*[@id='password']")).clear();
		// driver.findElement(By.id("username")).sendKeys("rahulsh");
		// driver.findElement(By.id("password")).clear();
		// driver.findElement(By.id("password")).sendKeys("gauss123");
		// driver.findElement(By.id("btn-login")).click();
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(
				By.xpath("//*[@id='wrapper']/section/div/aside[1]/ul/li[3]/a/span"))
				.click();
		driver.findElement(
				By.xpath("//*[@id='wrapper']/section/div/aside[1]/ul/li[3]/ul/li[2]/a"))
				.click();

		if (redeem_count == 0) {
			String text = driver
					.findElement(
							By.xpath("//*[@id='wrapper']/section/div/article/div[2]/div/table/tbody/tr[2]/td"))
					.getText();

			// to be openend for production run to see result
			// Assert.assertEquals(text, "No records found.");
			if (text.equals("No records found.")) {
				System.out.println(text);
				System.out.println("Test Case Pass");
			}
		} else if (redeem_count > 0) {

			// acc_summary_table
			WebElement table = driver.findElement(By
					.className("acc_summary_table"));

			// Now get all the TR elements from the table
			List<WebElement> allRows = table.findElements(By.tagName("tr"));

			int chips_count = allRows.size() - 1;

			if (chips_count == redeem_count) {

				// to be openend for production run to see result
				// Assert.assertEquals(purchase_count, chips_count);
				System.out.println("Chips Count from UI " + chips_count);
				System.out.println("TestCase Pass");
			}

		}

	}

	// @Test
	// public void alllinks(){
	// driver.get(baseUrl + "/");
	// List<WebElement> alllinkspresent=driver.findElements(By.tagName("a"));
	// driver.findElement(By.id("username")).clear();
	// driver.findElement(By.id("username")).sendKeys("rahulsh");
	// driver.findElement(By.id("password")).clear();
	// driver.findElement(By.id("password")).sendKeys("gauss123");
	// driver.findElement(By.id("btn-login")).click();
	// List<WebElement> alllinkspresent1=driver.findElements(By.tagName("a"));
	// for(int i=0; i< alllinkspresent1.size(); i++)

	// {

	// System.out.println(alllinkspresent1.get(i).getText());

	// }

	// }

	// URL Test
	/*
	 * @Test public void testURL() throws Exception { driver.get(baseUrl + "/");
	 * 
	 * String[] strUrl =
	 * {"Home","about-us","customer-support","customer-support/add-feedback"};
	 * String[] strNameDisplay = {"Home","About Us","Contact Us","Feedback"};
	 * 
	 * for(int index =0; index<strNameDisplay.length; index++) {
	 * driver.findElement(By.linkText( strNameDisplay[index]) ).click();
	 * 
	 * String strCurrentURL = driver.getCurrentUrl();
	 * 
	 * if( strCurrentURL.toUpperCase().contains( strUrl[index].toUpperCase())) {
	 * System.out.println("Yes"); } else { System.out.println("Fail"); } }
	 * 
	 * }
	 */

	/*
	 * //Slider Test
	 * 
	 * @Test public void testScrollSliderImage() throws Exception {
	 * driver.get("http://www.adda52.com/poker/tournament-schedule"); int
	 * intLocation = common.sliderImage;
	 * 
	 * Point pLocation =
	 * driver.findElement(By.xpath("html/body/div[3]/section/div/aside/div/a/img"
	 * )).getLocation();
	 * 
	 * try{
	 * 
	 * int x = pLocation.getX(); int y = pLocation.getY();
	 * 
	 * if(intLocation == 0 && strLocation == "143*143") { intLocation = 280; }
	 * else if (strLocation == "143*143") { intLocation += 1; } }
	 * catch(Exception ex) { System.out.println("Invalid Location"); }
	 * common.sliderImage = intLocation;
	 * 
	 * }
	 */

	@After
	public void pushError() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	@AfterClass
	public static void tearDown() throws Exception {
		driver.quit();
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	private String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		} finally {
			acceptNextAlert = true;
		}
	}

}
