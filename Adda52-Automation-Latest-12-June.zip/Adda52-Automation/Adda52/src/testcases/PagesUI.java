package testcases;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class PagesUI {
	  private WebDriver driver;
	  private String baseUrl;
	  private boolean acceptNextAlert = true;
	  private StringBuffer verificationErrors = new StringBuffer();

	  @Before
	  public void setUp() throws Exception {
	    driver = new FirefoxDriver();
	    baseUrl = "http://adda52.org/";
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	  }

// Poker Landing Page	  
	  @Test
	  	public void testPokerLanding() throws Exception {
		    driver.get(baseUrl);
		    driver.findElement(By.linkText("Adda52.com")).click();
//		    assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com", driver.getTitle());
//		    driver.findElement(By.cssSelector("img..firepath-matching-node")).click();
		    driver.findElement(By.id("username")).clear();
		    driver.findElement(By.id("username")).sendKeys("rahulsh");
		    driver.findElement(By.id("password")).clear();
		    driver.findElement(By.id("password")).sendKeys("gauss123");
		    driver.findElement(By.id("btn-login")).click();
		    assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com", driver.getTitle());
		    driver.findElement(By.linkText("Poker")).click();
		    assertEquals("Play Free Poker Game Online in India at Adda52 - Win Real Cash", driver.getTitle());
		    
	    driver.findElement(By.xpath("//*[@id='slideshow']"));
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='slideshow']")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='middle']/div/article/h1")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//section[@id='middle']/div")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='middle']/div/aside/div[1]")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='middle']/div/aside/div[1]/h3")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='middle']/div/aside/div[2]")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='middle']/div/aside/div[2]/h3")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='footer']/div[1]")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='footer']")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.linkText("How to Play Poker")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.linkText("Tournament Schedule")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.linkText("Promotions")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.linkText("Customer Support")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.linkText("My Account")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.linkText("Poker Rooms")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.linkText("Video Tutorial")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='wrapper']/header")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

// How To Play Poker	
	  	  public void testHowToPlayPoker() throws Exception {
		    driver.get(baseUrl);
		    driver.findElement(By.linkText("Adda52.com")).click();
//		    assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com", driver.getTitle());
		    driver.findElement(By.id("username")).clear();
		    driver.findElement(By.id("username")).sendKeys("rahulsh");
		    driver.findElement(By.id("password")).clear();
		    driver.findElement(By.id("password")).sendKeys("gauss123");
		    driver.findElement(By.id("btn-login")).click();
		    assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com", driver.getTitle());
		    driver.findElement(By.linkText("Poker")).click();
		    assertEquals("Play Free Poker Game Online in India at Adda52 - Win Real Cash", driver.getTitle());
		    driver.findElement(By.linkText("How to Play Poker")).click();
		    assertEquals("How to Play Texas Holdem Poker Online & Learn Poker Game Rules @ Adda52.com", driver.getTitle());
		    try {
		      assertTrue(isElementPresent(By.xpath("//*[@id='wrapper']/figure")));
		    } catch (Error e) {
		      verificationErrors.append(e.toString());
		    }
		    try {
		      assertTrue(isElementPresent(By.xpath("//*[@id='wrapper']/div")));
		    } catch (Error e) {
		      verificationErrors.append(e.toString());
		    }
		    try {
		      assertTrue(isElementPresent(By.xpath("//*[@id='wrapper']/section/div/aside[1]/ul/li[1]/a/span")));
		    } catch (Error e) {
		      verificationErrors.append(e.toString());
		    }
		    try {
		      assertTrue(isElementPresent(By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[2]/a/span")));
		    } catch (Error e) {
		      verificationErrors.append(e.toString());
		    }
		    try {
		      assertTrue(isElementPresent(By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[3]/a/span")));
		    } catch (Error e) {
		      verificationErrors.append(e.toString());
		    }
		    try {
		      assertTrue(isElementPresent(By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[4]/a/span")));
		    } catch (Error e) {
		      verificationErrors.append(e.toString());
		    }
		    try {
		      assertTrue(isElementPresent(By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[5]/a/span")));
		    } catch (Error e) {
		      verificationErrors.append(e.toString());
		    }
		    try {
		      assertTrue(isElementPresent(By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[6]/a/span")));
		    } catch (Error e) {
		      verificationErrors.append(e.toString());
		    }
		    try {
		      assertTrue(isElementPresent(By.xpath("//*[@id='wrapper']/section/div/article")));
		    } catch (Error e) {
		      verificationErrors.append(e.toString());
		    }
		    try {
		      assertTrue(isElementPresent(By.xpath("//*[@id='float']/a/img")));
		    } catch (Error e) {
		      verificationErrors.append(e.toString());
		    }
		  }
	  
// Tournament Schedule
	  	@Test
	    public void testTournamentSchedule() throws Exception {
		    driver.get(baseUrl);
		    driver.findElement(By.linkText("Adda52.com")).click();
//		    assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com", driver.getTitle());
		    driver.findElement(By.id("username")).clear();
		    driver.findElement(By.id("username")).sendKeys("rahulsh");
		    driver.findElement(By.id("password")).clear();
		    driver.findElement(By.id("password")).sendKeys("gauss123");
		    driver.findElement(By.id("btn-login")).click();
		    assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com", driver.getTitle());
		    driver.findElement(By.linkText("Poker")).click();
		    assertEquals("Play Free Poker Game Online in India at Adda52 - Win Real Cash", driver.getTitle());
	      
		    driver.findElement(By.linkText("Tournament Schedule")).click();
	        assertEquals("Poker Tournament Schedule � At Adda52.com", driver.getTitle());
	      try {
	        assertTrue(isElementPresent(By.xpath("//*[@id='wrapper']/figure")));
	      } catch (Error e) {
	        verificationErrors.append(e.toString());
	      }
	      try {
	        assertTrue(isElementPresent(By.xpath("//*[@id='wrapper']/div")));
	      } catch (Error e) {
	        verificationErrors.append(e.toString());
	      }
	      try {
	        assertTrue(isElementPresent(By.xpath("//*[@id='wrap']/h1")));
	      } catch (Error e) {
	        verificationErrors.append(e.toString());
	      }
	      try {
	        assertTrue(isElementPresent(By.xpath("//*[@id='wrap']/p")));
	      } catch (Error e) {
	        verificationErrors.append(e.toString());
	      }
	      try {
	        assertTrue(isElementPresent(By.xpath("//div[@id='wrap']/div[2]/div")));
	      } catch (Error e) {
	        verificationErrors.append(e.toString());
	      }
	      try {
	        assertTrue(isElementPresent(By.xpath("//*[@id='wrapper']/section/div/article/strong")));
	      } catch (Error e) {
	        verificationErrors.append(e.toString());
	      }
	      try {
	        assertTrue(isElementPresent(By.xpath("//*[@id='float']/a/img")));
	      } catch (Error e) {
	        verificationErrors.append(e.toString());
	      }
	    }

	  
// Rummy Landing Page
	  @Test
	  public void testRummyLanding() throws Exception {
	    driver.get(baseUrl);
//	    assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com", driver.getTitle());
	    driver.findElement(By.linkText("Adda52.com")).click();
	    assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com", driver.getTitle());
	    driver.findElement(By.id("username")).clear();
	    driver.findElement(By.id("username")).sendKeys("rahulsh");
	    driver.findElement(By.id("password")).clear();
	    driver.findElement(By.id("password")).sendKeys("gauss123");
	    driver.findElement(By.id("btn-login")).click();
	    assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com", driver.getTitle());
	    driver.findElement(By.linkText("Rummy")).click();
	    assertEquals("Online Rummy India � Play Free or Cash Indian Rummy Online @ Adda52", driver.getTitle());
	    try {
	      assertTrue(isElementPresent(By.linkText("How to Play Rummy")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.linkText("Tournament Schedule")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.linkText("Home")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.linkText("Promotions")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.linkText("Customer Support")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.linkText("My Account")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.linkText("Video Tutorial")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.xpath("//*[@id='slideshow']")).click();
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='slideshow']")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='middle']/div/article")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='middle']/div/aside/div[1]")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='middle']/div/aside/div[2]/figure")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

// Hoe To Play Rummy
	  @Test
	  public void testHowToPlayRummy() throws Exception {
	    driver.get(baseUrl);
//	    assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com", driver.getTitle());
	    driver.findElement(By.linkText("Adda52.com")).click();
	    assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com", driver.getTitle());
	    driver.findElement(By.id("username")).clear();
	    driver.findElement(By.id("username")).sendKeys("rahulsh");
	    driver.findElement(By.id("password")).clear();
	    driver.findElement(By.id("password")).sendKeys("gauss123");
	    driver.findElement(By.id("btn-login")).click();
	    assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com", driver.getTitle());
	    driver.findElement(By.linkText("Rummy")).click();
	    assertEquals("Online Rummy India � Play Free or Cash Indian Rummy Online @ Adda52", driver.getTitle());
	    driver.findElement(By.linkText("How to Play Rummy")).click();
	    assertEquals("Learn How to Play Rummy Card Game Online", driver.getTitle());
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='wrapper']/figure")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='wrapper']/section/div/aside[1]/ul/li[1]/a/span")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[3]/a/span")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[4]/a/span")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[5]/a/span")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[6]/a/span")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='wrapper']/div")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='wrapper']/section/div/article")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='float']/a/img")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }
	  
// Rummy Tournaments
	  @Test
	  public void testRummyTournament() throws Exception {
	    driver.get(baseUrl);
//	    assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com", driver.getTitle());
	    driver.findElement(By.linkText("Adda52.com")).click();
	    assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com", driver.getTitle());
	    driver.findElement(By.linkText("Rummy")).click();
	    assertEquals("Online Rummy India � Play Free or Cash Indian Rummy Online @ Adda52", driver.getTitle());
	    driver.findElement(By.linkText("Tournament Schedule")).click();
	    assertEquals("Play Free Rummy Tournaments & Cash Rummy Tournaments at Adda52.com", driver.getTitle());
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='wrapper']/figure")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='wrapper']/div")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='wrap']/h1")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='wrap']/p")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//div[@id='wrap']/div[2]/div")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='wrapper']/section/div/article/strong")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='float']/a/img")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }
	  
	  
	  @After
	  public void tearDown() throws Exception {
	    driver.quit();
	    String verificationErrorString = verificationErrors.toString();
	    if (!"".equals(verificationErrorString)) {
	      fail(verificationErrorString);
	    }
	  }
	  private boolean isElementPresent(By by) {
	    try {
	      driver.findElement(by);
	      return true;
	    } catch (NoSuchElementException e) {
	      return false;
	    }
	  }

	  private boolean isAlertPresent() {
	    try {
	      driver.switchTo().alert();
	      return true;
	    } catch (NoAlertPresentException e) {
	      return false;
	    }
	  }

	  private String closeAlertAndGetItsText() {
	    try {
	      Alert alert = driver.switchTo().alert();
	      String alertText = alert.getText();
	      if (acceptNextAlert) {
	        alert.accept();
	      } else {
	        alert.dismiss();
	      }
	      return alertText;
	    } finally {
	      acceptNextAlert = true;
	    }
	  }
}

