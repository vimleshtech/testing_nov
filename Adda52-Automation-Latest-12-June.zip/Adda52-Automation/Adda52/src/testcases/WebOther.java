//=======================================================================================
// --- Created By: Rahul Shrivastava
// --- Created Date: 16-06-2014
// --- Modified Date: 
// --- Modified By: 
//=======================================================================================

package testcases;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import utilities.Common;

public class WebOther {
	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();
	private Map<String, String> innerResultMap = null;
	private Common common = new Common();

	@Before
	public void setUp() throws Exception {
		driver = new FirefoxDriver();
		baseUrl = "http://adda52.org/";
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Test
	public void testTC0765() throws Exception {

		driver.get(baseUrl + "/");

		driver.findElement(By.xpath("//*[@id='menu']/li[2]/a")).click();

	}

	@Test
	public void testTC0754() throws Exception {
		driver.get(baseUrl + "/");

		driver.findElement(By.xpath("//*[@id='logo']/a")).click();

		try {
			if (driver.findElement(By.xpath("//*[@id='game_list']/li[1]/a"))
					.isEnabled()) {

				innerResultMap.put("TC0754", "PASS");

			} else {
				innerResultMap.put("TC0754", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		common.getInnerResultMap().putAll(innerResultMap);

	}

	@Test
	public void testTC0755() throws Exception {
		driver.get(baseUrl + "/");
		assertEquals(
				"Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
				driver.getTitle());
		driver.findElement(By.linkText("Adda52.com")).click();
		assertEquals(
				"Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
				driver.getTitle());
		driver.findElement(By.linkText("Poker")).click();
		assertEquals(
				"Play Free Poker Game Online in India at Adda52 - Win Real Cash",
				driver.getTitle());
		driver.findElement(By.id("slider_signup")).click();
		driver.findElement(By.cssSelector("body")).click();
		assertTrue(isElementPresent(By.id("slider_signup")));

		try {
			if (driver.findElement(By.id("slider_signup")).isDisplayed()) {

				innerResultMap.put("TC0755", "PASS");

			} else {
				innerResultMap.put("TC0755", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		common.getInnerResultMap().putAll(innerResultMap);

	}

	@Test
	public void testTC0757() throws Exception {
		driver.get(baseUrl + "/");
		assertEquals(
				"Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
				driver.getTitle());
		driver.findElement(By.linkText("Adda52.com")).click();
		assertEquals(
				"Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
				driver.getTitle());
		driver.findElement(By.linkText("Poker")).click();
		assertEquals(
				"Play Free Poker Game Online in India at Adda52 - Win Real Cash",
				driver.getTitle());
		assertTrue(isElementPresent(By.linkText("How to Play Poker")));
		assertTrue(isElementPresent(By.linkText("Tournament Schedule")));
		assertTrue(isElementPresent(By.linkText("Promotions")));
		assertTrue(isElementPresent(By.linkText("Customer Support")));
		assertTrue(isElementPresent(By.id("btnSignUp")));
		assertTrue(isElementPresent(By.linkText("Poker Rooms")));
		assertTrue(isElementPresent(By.linkText("Video Tutorial")));
	}

	@Test
	public void testTC0759() throws Exception {
		driver.get(baseUrl + "/");
		assertEquals(
				"Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
				driver.getTitle());
		driver.findElement(By.linkText("Adda52.com")).click();
		assertEquals(
				"Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
				driver.getTitle());
		driver.findElement(By.id("username")).click();
		driver.findElement(By.id("username")).clear();
		driver.findElement(By.id("username")).sendKeys("rahulsh");
		driver.findElement(By.id("password")).clear();
		driver.findElement(By.id("password")).sendKeys("gauss123");
		driver.findElement(By.id("btn-login")).click();
		assertEquals(
				"Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
				driver.getTitle());
		driver.findElement(By.linkText("Poker")).click();
		assertEquals(
				"Play Free Poker Game Online in India at Adda52 - Win Real Cash",
				driver.getTitle());
		driver.findElement(By.linkText("How to Play Poker")).click();
		assertEquals(
				"How to Play Texas Holdem Poker Online & Learn Poker Game Rules @ Adda52.com",
				driver.getTitle());
		assertTrue(isElementPresent(By.cssSelector("img.png_bg")));

		try {
			if (driver.findElement(By.xpath("//*[@id='float']/a/img"))
					.isDisplayed()) {

				innerResultMap.put("TC0759", "PASS");

			} else {
				innerResultMap.put("TC0759", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		common.getInnerResultMap().putAll(innerResultMap);

	}

	@Test
	  public void testTC0760() throws Exception {
	    driver.get(baseUrl + "/");
	    assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com", driver.getTitle());
	    driver.findElement(By.id("username")).clear();
	    driver.findElement(By.id("username")).sendKeys("rahulsh");
	    driver.findElement(By.id("password")).clear();
	    driver.findElement(By.id("password")).sendKeys("gauss123");
	    driver.findElement(By.id("btn-login")).click();
	    assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com", driver.getTitle());
	    driver.findElement(By.linkText("Poker")).click();
	    assertEquals("Play Free Poker Game Online in India at Adda52 - Win Real Cash", driver.getTitle());
	    driver.findElement(By.linkText("How to Play Poker")).click();
	    assertEquals("How to Play Texas Holdem Poker Online & Learn Poker Game Rules @ Adda52.com", driver.getTitle());
	    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | name=fbMainContainer | ]]
	    // driver.findElement(By.id("fbInspectButton")).click();
	    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | null | ]]
	    // driver.findElement(By.cssSelector("article.leftEx.firepath-matching-node")).click();
		
	    String content = Common.readContent("TC0760-Play-Texas-Holdem-Poker-Online");
		String UIContent = driver.findElement(By.xpath("//*[@id='wrapper']/section/div/article")).getText();
		UIContent = UIContent.replaceAll("\\r|\\n", "");
		Assert.assertTrue(UIContent.contentEquals(content));
		
	    //assertTrue(isElementPresent(By.cssSelector("h2")));
	  }
	
	@Test
	public void testTC0766() throws Exception {
		driver.get(baseUrl + "/");
		assertEquals(
				"Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
				driver.getTitle());
		driver.findElement(By.linkText("Adda52.com")).click();
		assertEquals(
				"Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
				driver.getTitle());
		driver.findElement(By.id("username")).clear();
		driver.findElement(By.id("username")).sendKeys("rahulsh");
		driver.findElement(By.id("password")).clear();
		driver.findElement(By.id("password")).sendKeys("gauss123");
		driver.findElement(By.id("btn-login")).click();
		assertEquals(
				"Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
				driver.getTitle());
		assertEquals(
				"Username",
				driver.findElement(
						By.cssSelector("div.toptext.firepath-matching-node"))
						.getText());
		assertTrue(isElementPresent(By
				.xpath("//*[@id='top_login']/div/div[1]/div[1]/div[2]")));
		assertTrue(isElementPresent(By
				.xpath("//*[@id='top_login']/div/div[2]/div[1]")));
		assertTrue(isElementPresent(By
				.xpath("//*[@id='top_login']/div/div[2]/div[2]")));
		assertTrue(isElementPresent(By
				.xpath("//*[@id='top_login']/div/div[3]/div[1]")));
		assertTrue(isElementPresent(By
				.xpath("//*[@id='top_login']/div/div[3]/div[2]")));
		assertTrue(isElementPresent(By.xpath("//*[@id='logout']/img")));
	}

	@Test
	public void testTC0768() throws Exception {
		driver.get(baseUrl + "/");
		assertEquals(
				"Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
				driver.getTitle());
		driver.findElement(By.linkText("Adda52.com")).click();
		assertEquals(
				"Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
				driver.getTitle());
		driver.findElement(By.id("username")).clear();
		driver.findElement(By.id("username")).sendKeys("rahulsh");
		driver.findElement(By.id("password")).clear();
		driver.findElement(By.id("password")).sendKeys("gauss123");
		driver.findElement(By.id("btn-login")).click();
		assertEquals(
				"Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
				driver.getTitle());
		driver.findElement(By.linkText("Poker")).click();
		assertEquals(
				"Play Free Poker Game Online in India at Adda52 - Win Real Cash",
				driver.getTitle());
		driver.findElement(By.linkText("How to Play Poker")).click();
		assertEquals(
				"How to Play Texas Holdem Poker Online & Learn Poker Game Rules @ Adda52.com",
				driver.getTitle());
		driver.getCurrentUrl();

		try {
			if (driver.getCurrentUrl() == "http://adda52.org/poker/how-to-play") {

				innerResultMap.put("TC0768", "PASS");

			} else {
				innerResultMap.put("TC0768", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		common.getInnerResultMap().putAll(innerResultMap);

	}

	@Test
	public void testTC0769() throws Exception {
		driver.get(baseUrl + "/");
		assertEquals(
				"Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
				driver.getTitle());
		driver.findElement(By.linkText("Adda52.com")).click();
		driver.findElement(By.linkText("Adda52.com")).click();
		assertEquals(
				"Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
				driver.getTitle());
		driver.findElement(By.id("username")).clear();
		driver.findElement(By.id("username")).sendKeys("rahulsh");
		driver.findElement(By.id("password")).clear();
		driver.findElement(By.id("password")).sendKeys("gauss123");
		driver.findElement(By.id("btn-login")).click();
		assertEquals(
				"Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
				driver.getTitle());
		driver.findElement(By.linkText("Poker")).click();
		assertEquals(
				"Play Free Poker Game Online in India at Adda52 - Win Real Cash",
				driver.getTitle());
		driver.findElement(By.linkText("Promotions")).click();
		assertEquals("Poker Promotions and Bonuses in India @ Adda52.com",
				driver.getTitle());

		driver.getCurrentUrl();
		try {
			if (driver.getCurrentUrl() == "http://adda52.org/poker/promotions") {

				innerResultMap.put("TC0769", "PASS");

			} else {
				innerResultMap.put("TC0769", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		common.getInnerResultMap().putAll(innerResultMap);
	}

	@Test
	public void testTC0771() throws Exception {
		driver.get(baseUrl + "/");
		assertEquals(
				"Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
				driver.getTitle());
		driver.findElement(By.id("username")).clear();
		driver.findElement(By.id("username")).sendKeys("rahulsh");
		driver.findElement(By.id("password")).clear();
		driver.findElement(By.id("password")).sendKeys("gauss123");
		driver.findElement(By.id("btn-login")).click();
		assertEquals(
				"Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
				driver.getTitle());
		driver.findElement(By.linkText("Poker")).click();
		assertEquals(
				"Play Free Poker Game Online in India at Adda52 - Win Real Cash",
				driver.getTitle());
		driver.findElement(By.linkText("Promotions")).click();
		assertEquals("Poker Promotions and Bonuses in India @ Adda52.com",
				driver.getTitle());
		driver.findElement(By.linkText("Loyalty Program")).click();
		assertEquals(
				"Loyalty Program at Adda52 - Exclusive Rewards Program for Cash Players",
				driver.getTitle());
		try {
			assertTrue(isElementPresent(By
					.xpath("//*[@id='wrapper']/section/div/article/h1[2]/a/img")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
	}

	@Test
	public void testTC0772() throws Exception {
		driver.get(baseUrl + "/");
		assertEquals(
				"Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
				driver.getTitle());
		driver.findElement(By.id("username")).clear();
		driver.findElement(By.id("username")).sendKeys("rahulsh");
		driver.findElement(By.id("password")).clear();
		driver.findElement(By.id("password")).sendKeys("gauss123");
		driver.findElement(By.id("btn-login")).click();
		assertEquals(
				"Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
				driver.getTitle());
		driver.findElement(By.linkText("Poker")).click();
		assertEquals(
				"Play Free Poker Game Online in India at Adda52 - Win Real Cash",
				driver.getTitle());
		driver.findElement(By.linkText("Promotions")).click();
		assertEquals("Poker Promotions and Bonuses in India @ Adda52.com",
				driver.getTitle());
		driver.findElement(By.linkText("Loyalty Program")).click();
		assertEquals(
				"Loyalty Program at Adda52 - Exclusive Rewards Program for Cash Players",
				driver.getTitle());
		try {
			assertTrue(isElementPresent(By
					.xpath("//*[@id='wrapper']/section/div/article/h1[2]/a/img")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(
				By.xpath("//*[@id='wrapper']/section/div/article/h1[2]/a/img"))
				.click();
		driver.getCurrentUrl();

		try {
			if (driver.getCurrentUrl() == "http://adda52.org/my-account/account-summary") {

				innerResultMap.put("TC0772", "PASS");

			} else {
				innerResultMap.put("TC0772", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		common.getInnerResultMap().putAll(innerResultMap);
	}

	@Test
	public void testTC0777() throws Exception {
		driver.get(baseUrl + "/");
		assertEquals(
				"Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
				driver.getTitle());
		driver.findElement(By.id("username")).clear();
		driver.findElement(By.id("username")).sendKeys("rahulsh");
		driver.findElement(By.id("password")).clear();
		driver.findElement(By.id("password")).sendKeys("gauss123");
		driver.findElement(By.id("btn-login")).click();
		assertEquals(
				"Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
				driver.getTitle());
		driver.findElement(By.linkText("Poker")).click();
		assertEquals(
				"Play Free Poker Game Online in India at Adda52 - Win Real Cash",
				driver.getTitle());
		driver.findElement(By.linkText("Poker Rooms")).click();
		assertEquals(
				"Indian Poker Rooms � Offline and Online Poker Rooms @ Adda52.com",
				driver.getTitle());
		driver.findElement(By.xpath("//*[@id='wrapper']/section/div/article/a"))
				.click();

	}

	@Test
	public void testTC0786() throws Exception {
		driver.get(baseUrl + "/");
		assertEquals(
				"Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
				driver.getTitle());
		driver.findElement(By.linkText("Rummy")).click();
		assertEquals(
				"Online Rummy India � Play Free or Cash Indian Rummy Online @ Adda52",
				driver.getTitle());

	}

	@Test
	public void testTC0787() throws Exception {
		driver.get(baseUrl + "/");
		assertEquals(
				"Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
				driver.getTitle());
		driver.findElement(By.id("username")).clear();
		driver.findElement(By.id("username")).sendKeys("rahulsh");
		driver.findElement(By.id("password")).clear();
		driver.findElement(By.id("password")).sendKeys("gauss123");
		driver.findElement(By.id("btn-login")).click();
		assertEquals(
				"Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com",
				driver.getTitle());
		driver.findElement(By.linkText("Rummy")).click();
		assertEquals(
				"Online Rummy India � Play Free or Cash Indian Rummy Online @ Adda52",
				driver.getTitle());
		driver.findElement(By.linkText("How to Play Rummy")).click();
		assertEquals("Learn How to Play Rummy Card Game Online",
				driver.getTitle());

	}

	@After
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	private String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		} finally {
			acceptNextAlert = true;
		}
	}
}
