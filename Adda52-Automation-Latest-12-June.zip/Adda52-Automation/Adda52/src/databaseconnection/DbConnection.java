//=======================================================================================
// --- Created By: Rahul Shrivastava
// --- Created Date: 
// --- Modified Date: 
// --- Modified By: 
//=======================================================================================

package databaseconnection;

import static org.junit.Assert.assertNotEquals;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.junit.Test;

public class DbConnection {

	@Test
	public void dbTest() {
		String user_name = "NaN";
		String dbUrl = "jdbc:mysql://127.0.0.1:3306/cardplay"; // This URL is based on your IP address
		// String dbUrl = "jdbc:mysql://192.168.1.139:3306/adda52"; //This URL
		// is based on your IP address
		String username = ""; // Default user name is root
		String password = ""; // Default password is root
		String dbClass = "com.mysql.jdbc.Driver";
		String query = "Select user_name from cp_user where user_id = 70931";

		try {

			Class.forName(dbClass);
			Connection con = DriverManager.getConnection(dbUrl, username, password);
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(query);

			while (rs.next()) {
				user_name = rs.getString(1);
				System.out.println(user_name);
			} // end while

			assertNotEquals("NaN", user_name);
			con.close();
		} // end try

		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		catch (SQLException e) {
			e.printStackTrace();
		}

	} // end main
	
	public static boolean isBuddy(String user_name){
		Connection con = getConnection();
		String user_id = null;
		int buddy_count = 0;
		ResultSet rs = null;
		Statement stmt = null;
		try {
			stmt = con.createStatement();
			String user_query = "select user_id from cp_user where user_name = '" +user_name+"'";
			String buddy_query = "select count(buddy_id) from cp_buddy where user_id =" + user_id ;
			rs = stmt.executeQuery(user_query);
			while(rs.next()){
				user_id = rs.getString(1);
				System.out.println("-->"+user_id);
			}
			if(user_id != null){
			  rs = 	stmt.executeQuery(buddy_query);
			  while(rs.next()){
				buddy_count = rs.getInt(1);
			  }
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			if(con!= null){
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(rs != null){
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null){
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		if(buddy_count > 0){
			return false;
		}else{
			return true;
		}
		
		
	}
	
	public static ArrayList<String> getBuddyList(String user_name){
		
		Connection con = getConnection();
		int buddy_count = 0;
		ResultSet rs = null;
		Statement stmt = null;
		String buddy = "";
		ArrayList<String> buddyList = new ArrayList<String>();
		try {
			stmt = con.createStatement();

			String buddy_query = "select buddy_id from cp_buddy where user_id in (select user_id from cp_user where user_name = " + user_name + ")" ;
			String buddy_querya = "(select  u1.user_name  from cp_user u1,cp_buddy b1 where b1.user_id in  (select user_id from cp_user where user_name = " + user_name + ") and b1.buddy_id = u1.user_id)";
			rs = stmt.executeQuery(buddy_querya);
			while(rs.next()){
				buddy = rs.getString(1);
				buddyList.add(buddy);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			if(con!= null){
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(rs != null){
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null){
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return buddyList;
		
	}
	
	// Purchase Summary
	public static int getPurchaseSummary(String userName) {

		Connection con = getConnection();
		ResultSet rs = null;
		Statement stmt = null;
		int purchase_count = 0;
		try {
			stmt = con.createStatement();

			String purchase_txn_query = "select total_approved_txn from cp_user_purchase_transaction_history where user_id in (select user_id from cp_user where user_name = '"  + userName + "')";
			rs = stmt.executeQuery(purchase_txn_query);
			while (rs.next()) {
				purchase_count = rs.getInt(1);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return purchase_count;

	}

	// Redeem Summary	
	public static int getRedeemSummary(String userName) {

		Connection con = getConnection();
		ResultSet rs = null;
		Statement stmt = null;
		int redeem_count = 0;
		try {
			stmt = con.createStatement();

			String purchase_txn_query = "select status from cp_user_purchase_transaction_history where user_id in (select user_id from cp_user where user_name = '"  + userName + "')";
			rs = stmt.executeQuery(purchase_txn_query);
			while (rs.next()) {
				redeem_count = rs.getInt(1);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return redeem_count;

	}
	
	public static Connection getConnection(){
		
//		String user_name = "NaN";
		String dbUrl = "jdbc:mysql://localhost/cardplay"; // This URL is
																// based on your
																// IP address
		// String dbUrl = "jdbc:mysql://192.168.1.139:3306/adda52"; //This URL
		// is based on your IP address
		String username = ""; // Default user name is root
		String password = ""; // Default password is root
		String dbClass = "com.mysql.jdbc.Driver";
		Connection con = null;
		
		
		try {
			Class.forName(dbClass);
            con = DriverManager.getConnection(dbUrl, username,
					password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return con;
	}


	
	public void setUp() {
		// TODO Auto-generated method stub
		
	}

}
 // end class